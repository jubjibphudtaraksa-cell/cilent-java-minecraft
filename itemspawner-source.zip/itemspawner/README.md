# Item Spawner (Fabric 1.21.11)

Press F10 in game to open a UI that spawns items.

## Build a real jar without a PC (GitHub)
1. Create a new repository on github.com.
2. Upload the contents of this folder (including the hidden `.github` folder).
3. Open the Actions tab -> the `build` run -> Artifacts -> download `itemspawner-jar`.
4. Unzip it and use `itemspawner-1.0.0.jar` (NOT the `-sources` jar) in your mods folder.

## Build on a PC
Install JDK 21 and Gradle, then run `gradle build`. The jar is in `build/libs/`.
