package com.example.itemspawner;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

public class ItemSpawnerClient implements ClientModInitializer {
	public static KeyMapping OPEN_KEY;

	@Override
	public void onInitializeClient() {
		OPEN_KEY = KeyBindingHelper.registerKeyBinding(new KeyMapping(
				"key.itemspawner.open",
				InputConstants.Type.KEYSYM,
				GLFW.GLFW_KEY_F10,
				KeyMapping.Category.MISC
		));

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (OPEN_KEY.consumeClick()) {
				if (mc.player != null && mc.screen == null) {
					mc.setScreen(new SpawnerScreen());
				}
			}
		});
	}
}
