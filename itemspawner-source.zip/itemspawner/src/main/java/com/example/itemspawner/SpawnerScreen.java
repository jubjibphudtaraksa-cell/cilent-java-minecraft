package com.example.itemspawner;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SpawnerScreen extends Screen {
	private static final int COLS = 12;
	private static final int ROWS = 6;
	private static final int CELL = 22;
	private static final int GRID_TOP = 50;

	private final List<Item> allItems = new ArrayList<>();
	private final Map<Item, String> searchText = new HashMap<>();
	private List<Item> filtered = new ArrayList<>();

	private final List<Button> itemButtons = new ArrayList<>();
	private final Map<Button, ItemStack> buttonStacks = new HashMap<>();

	private EditBox searchBox;
	private EditBox amountBox;
	private int page = 0;
	private String query = "";

	public SpawnerScreen() {
		super(Component.literal("Item Spawner"));
		for (Item item : BuiltInRegistries.ITEM) {
			if (item == Items.AIR) continue;
			allItems.add(item);
			String name = item.getDefaultInstance().getHoverName().getString();
			String id = BuiltInRegistries.ITEM.getKey(item).toString();
			searchText.put(item, (name + " " + id).toLowerCase(Locale.ROOT));
		}
		filtered = new ArrayList<>(allItems);
	}

	@Override
	protected void init() {
		itemButtons.clear();
		buttonStacks.clear();

		int gridW = COLS * CELL;
		int left = (this.width - gridW) / 2;

		searchBox = new EditBox(this.font, left, 22, 170, 18, Component.literal("Search"));
		searchBox.setHint(Component.literal("Search..."));
		searchBox.setValue(query);
		searchBox.setResponder(text -> {
			query = text;
			applyFilter();
		});
		addRenderableWidget(searchBox);

		amountBox = new EditBox(this.font, left + gridW - 60, 22, 60, 18, Component.literal("Amount"));
		amountBox.setValue("64");
		amountBox.setFilter(s -> s.isEmpty() || s.matches("\\d{1,4}"));
		addRenderableWidget(amountBox);

		addRenderableWidget(Button.builder(Component.literal("<"), b -> changePage(-1))
				.bounds(left, this.height - 28, 40, 20).build());
		addRenderableWidget(Button.builder(Component.literal(">"), b -> changePage(1))
				.bounds(left + gridW - 40, this.height - 28, 40, 20).build());

		setInitialFocus(searchBox);
		applyFilter();
	}

	private void applyFilter() {
		String q = query.toLowerCase(Locale.ROOT).trim();
		filtered = new ArrayList<>();
		for (Item item : allItems) {
			if (q.isEmpty() || searchText.get(item).contains(q)) {
				filtered.add(item);
			}
		}
		page = 0;
		rebuildGrid();
	}

	private int maxPage() {
		int perPage = COLS * ROWS;
		return Math.max(0, (filtered.size() - 1) / perPage);
	}

	private void changePage(int delta) {
		int newPage = Math.max(0, Math.min(maxPage(), page + delta));
		if (newPage != page) {
			page = newPage;
			rebuildGrid();
		}
	}

	private void rebuildGrid() {
		for (Button b : itemButtons) {
			removeWidget(b);
		}
		itemButtons.clear();
		buttonStacks.clear();

		int gridW = COLS * CELL;
		int left = (this.width - gridW) / 2;
		int perPage = COLS * ROWS;
		int start = page * perPage;
		int end = Math.min(filtered.size(), start + perPage);

		for (int i = start; i < end; i++) {
			Item item = filtered.get(i);
			int idx = i - start;
			int x = left + (idx % COLS) * CELL;
			int y = GRID_TOP + (idx / COLS) * CELL;

			ItemStack stack = new ItemStack(item);
			String name = stack.getHoverName().getString();
			String id = BuiltInRegistries.ITEM.getKey(item).toString();

			Button button = Button.builder(Component.empty(), b -> give(item))
					.bounds(x, y, CELL - 2, CELL - 2)
					.tooltip(Tooltip.create(Component.literal(name + " (" + id + ")")))
					.build();
			addRenderableWidget(button);
			itemButtons.add(button);
			buttonStacks.put(button, stack);
		}
	}

	private int parseAmount() {
		try {
			int n = Integer.parseInt(amountBox.getValue());
			return Math.max(1, n);
		} catch (NumberFormatException e) {
			return 1;
		}
	}

	private void give(Item item) {
		Minecraft mc = Minecraft.getInstance();
		LocalPlayer player = mc.player;
		if (player == null) return;

		int amount = parseAmount();
		String id = BuiltInRegistries.ITEM.getKey(item).toString();

		// Creative mode: put the item straight into a free inventory slot.
		if (player.isCreative() && mc.gameMode != null) {
			int count = Math.min(amount, item.getDefaultMaxStackSize());
			for (int i = 0; i < 36; i++) {
				if (player.getInventory().getItem(i).isEmpty()) {
					int menuSlot = i < 9 ? 36 + i : i;
					mc.gameMode.handleCreativeModeItemAdd(new ItemStack(item, count), menuSlot);
					return;
				}
			}
		}

		// Otherwise use /give (needs operator permission / cheats enabled).
		player.connection.sendCommand("give @s " + id + " " + amount);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		if (scrollY > 0) {
			changePage(-1);
		} else if (scrollY < 0) {
			changePage(1);
		}
		return true;
	}

	@Override
	public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
		super.render(g, mouseX, mouseY, delta);

		g.drawCenteredString(this.font, this.title, this.width / 2, 8, 0xFFFFFFFF);
		g.drawCenteredString(this.font,
				"Page " + (page + 1) + " / " + (maxPage() + 1) + "  (" + filtered.size() + " items)",
				this.width / 2, this.height - 22, 0xFFAAAAAA);

		for (Map.Entry<Button, ItemStack> e : buttonStacks.entrySet()) {
			Button b = e.getKey();
			g.renderItem(e.getValue(), b.getX() + 1, b.getY() + 1);
		}
	}
}
