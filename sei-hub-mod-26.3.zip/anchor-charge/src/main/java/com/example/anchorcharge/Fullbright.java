package com.example.anchorcharge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

/**
 * Fullbright: ใส่ Night Vision ฝั่งไคลเอนต์ (เซิร์ฟเวอร์ไม่รู้) ทำให้มองเห็นสว่างทุกที่
 * ถ้าเรามี Night Vision จริงอยู่แล้ว จะไม่แตะ และตอนปิดจะเอาออกเฉพาะอันที่เราใส่เอง
 */
public final class Fullbright {
    private static boolean ours = false;

    private Fullbright() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(Fullbright::tick);
    }

    private static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null) {
            ours = false;
            return;
        }
        if (ModuleManager.FULLBRIGHT.enabled) {
            if (!p.hasEffect(MobEffects.NIGHT_VISION)) {
                p.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION,
                        MobEffectInstance.INFINITE_DURATION, 0, false, false, false));
                ours = true;
            }
        } else if (ours) {
            p.getActiveEffectsMap().remove(MobEffects.NIGHT_VISION);
            ours = false;
        }
    }
}
