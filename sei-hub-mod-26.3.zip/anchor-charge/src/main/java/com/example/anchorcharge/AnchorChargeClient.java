package com.example.anchorcharge;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RespawnAnchorBlock;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import com.mojang.blaze3d.platform.InputConstants;

public class AnchorChargeClient implements ClientModInitializer {
    private static final int MAX_WAIT_TICKS = 10;

    private static boolean f10Was = false;
    private static BlockPos pending = null;
    private static int waited = 0;
    private static int chargeWait = -1;

    @Override
    public void onInitializeClient() {
        Lang.load();
        AutoCrystal.init();
        AutoTotem.init();
        AutoMlg.init();
        AutoMace.init();
        Aura.init();
        Esp.init();
        Fullbright.init();

        // วาง Respawn Anchor -> จำตำแหน่งไว้
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (ModuleManager.ANCHOR_CHARGE.enabled && world.isClientSide()) {
                ItemStack stack = player.getItemInHand(hand);
                if (stack.is(Items.RESPAWN_ANCHOR)) {
                    pending = new BlockPlaceContext(player, hand, stack, hit).getClickedPos();
                    waited = 0;
                    chargeWait = -1;
                }
            }
            return InteractionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(AnchorChargeClient::tick);

        // กด F10 เปิด UI (ปิดด้วย ESC)
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.getWindow() == null) return;
            boolean down = InputConstants.isKeyDown(InputConstants.KEY_F10);
            if (down && !f10Was && mc.player != null && mc.gui.screen() == null) {
                mc.gui.setScreen(new HubScreen());
            }
            f10Was = down;
        });
    }

    private static void tick(Minecraft mc) {
        if (pending == null) return;

        LocalPlayer player = mc.player;
        ClientLevel world = mc.level;
        if (!ModuleManager.ANCHOR_CHARGE.enabled || player == null || world == null || mc.gameMode == null) {
            pending = null;
            return;
        }

        // รอให้ anchor ถูกวางจริงก่อน
        if (!world.getBlockState(pending).is(Blocks.RESPAWN_ANCHOR)) {
            if (++waited > MAX_WAIT_TICKS) pending = null;
            return;
        }

        // ชาร์จแล้วไม่ต้องใส่ซ้ำ
        if (world.getBlockState(pending).getValue(RespawnAnchorBlock.CHARGE) > 0) {
            pending = null;
            return;
        }

        // หน่วงก่อนใส่โกลสโตน ตามช่วงที่ตั้งไว้
        if (chargeWait < 0) chargeWait = ModuleManager.ANCHOR_DELAY.randomTicks();
        if (chargeWait > 0) {
            chargeWait--;
            return;
        }

        int prevSlot = player.getInventory().getSelectedSlot();
        InteractionHand hand = null;

        if (player.getOffhandItem().is(Items.GLOWSTONE)) {
            hand = InteractionHand.OFF_HAND;
        } else {
            for (int i = 0; i < 9; i++) {
                if (player.getInventory().getItem(i).is(Items.GLOWSTONE)) {
                    player.getInventory().setSelectedSlot(i); // สลับเป็นโกลสโตน
                    hand = InteractionHand.MAIN_HAND;
                    break;
                }
            }
        }

        // ไม่มีโกลสโตน = ไม่ทำอะไร (ไม่คลิกมือเปล่า เพราะอาจระเบิด)
        if (hand == null) {
            pending = null;
            return;
        }

        BlockHitResult hit = faceHit(pending, player.getEyePosition());
        mc.gameMode.useItemOn(player, hand, hit);
        player.swing(hand);

        player.getInventory().setSelectedSlot(prevSlot); // สลับกลับช่องเดิม
        pending = null;
    }

    // คลิกที่หน้าของบล็อกที่ "หันเข้าหาตา" จริงๆ (ไม่ใช่ด้านบนเสมอ)
    // ถ้า anchor อยู่ระดับหัวหรือสูงกว่า ด้านบนมองไม่เห็น เซิร์ฟเวอร์จะปฏิเสธคลิก
    private static BlockHitResult faceHit(BlockPos pos, Vec3 eye) {
        Vec3 c = Vec3.atCenterOf(pos);
        Direction dir = Direction.getApproximateNearest(eye.x - c.x, eye.y - c.y, eye.z - c.z);

        double x = Mth.clamp(eye.x, pos.getX() + 0.05, pos.getX() + 0.95);
        double y = Mth.clamp(eye.y, pos.getY() + 0.05, pos.getY() + 0.95);
        double z = Mth.clamp(eye.z, pos.getZ() + 0.05, pos.getZ() + 0.95);

        if (dir.getAxis() == Direction.Axis.X) x = pos.getX() + (dir.getStepX() > 0 ? 1.0 : 0.0);
        if (dir.getAxis() == Direction.Axis.Y) y = pos.getY() + (dir.getStepY() > 0 ? 1.0 : 0.0);
        if (dir.getAxis() == Direction.Axis.Z) z = pos.getZ() + (dir.getStepZ() > 0 ? 1.0 : 0.0);

        return new BlockHitResult(new Vec3(x, y, z), dir, pos, false);
    }
}
