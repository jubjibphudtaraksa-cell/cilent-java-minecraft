package com.example.anchorcharge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Items;
import net.minecraft.world.InteractionHand;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.AABB;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Auto Mace: ถือ Mace -> หาผู้เล่นในวง FOV รอบเป้าเล็ง -> หันไปหา (silent) -> ตีตาม CPS
 *  - Silent Aim: เซิร์ฟเวอร์เห็นว่าเราหันไปหาเป้า แต่กล้องเราไม่ขยับ (ส่งมุม -> ตี -> ส่งมุมจริงกลับ ในแท็กเดียว)
 *  - วงกลม FOV วาดบนจอ ปรับขนาด/สีได้ (มีสายรุ้ง)
 */
public final class AutoMace {
    private static long nextAttack = 0;

    private AutoMace() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoMace::tick);
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR,
                Identifier.fromNamespaceAndPath("anchorcharge", "mace_fov"), AutoMace::renderHud);
    }

    private static boolean active(Minecraft mc) {
        LocalPlayer p = mc.player;
        return ModuleManager.AUTO_MACE.enabled && p != null && mc.level != null
                && mc.gameMode != null && mc.gui.screen() == null
                && p.getMainHandItem().is(Items.MACE);
    }

    private static void tick(Minecraft mc) {
        if (!active(mc)) return;
        LocalPlayer p = mc.player;

        long now = System.currentTimeMillis();
        if (now < nextAttack) return;

        Player target = findTarget(mc.level, p, ModuleManager.MACE_FOV.value);
        if (target == null) return;

        Setting.Range cps = ModuleManager.MACE_CPS;
        double rate = cps.lo >= cps.hi ? cps.lo : ThreadLocalRandom.current().nextDouble(cps.lo, cps.hi);
        nextAttack = now + (long) (1000.0 / Math.max(1.0, rate));

        Vec3 eye = p.getEyePosition();
        Vec3 aim = target.getBoundingBox().getCenter();
        boolean silent = ModuleManager.MACE_SILENT.value;

        if (silent) Rot.send(mc, p, Rot.yawTo(eye, aim), Rot.pitchTo(eye, aim)); // เซิร์ฟเวอร์เห็นว่าหันไปหาเป้า
        mc.gameMode.attack(p, target);
        p.swing(InteractionHand.MAIN_HAND);
        if (silent) Rot.syncReal(mc, p); // คืนมุมจริง กล้องเราไม่เคยขยับ
    }

    /** ผู้เล่นที่อยู่ในวง FOV, อยู่ในระยะตี, มองเห็นได้ ; เลือกคนที่ใกล้เป้าเล็งที่สุด */
    private static Player findTarget(ClientLevel w, LocalPlayer p, double fovDeg) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getViewVector(1.0f).normalize();
        double reach = p.entityInteractionRange();
        Player best = null;
        double bestAng = fovDeg;

        for (Player o : w.players()) {
            if (o == p || !o.isAlive() || o.isSpectator()) continue;
            AABB b = o.getBoundingBox();
            Vec3 near = new Vec3(
                    Mth.clamp(eye.x, b.minX, b.maxX),
                    Mth.clamp(eye.y, b.minY, b.maxY),
                    Mth.clamp(eye.z, b.minZ, b.maxZ));
            if (eye.distanceToSqr(near) > reach * reach) continue;
            if (!p.hasLineOfSight(o)) continue;

            Vec3 dir = b.getCenter().subtract(eye).normalize();
            double ang = Math.toDegrees(Math.acos(Mth.clamp(look.dot(dir), -1.0, 1.0)));
            if (ang <= bestAng) {
                bestAng = ang;
                best = o;
            }
        }
        return best;
    }

    // ===== วงกลม FOV =====
    private static void renderHud(GuiGraphicsExtractor ctx, DeltaTracker tc) {
        Minecraft mc = Minecraft.getInstance();
        if (!ModuleManager.AUTO_MACE.enabled || !ModuleManager.MACE_CIRCLE.value
                || mc.player == null || mc.gui.screen() != null || mc.gui.hud.isHidden()) return;

        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();
        double vfov = Math.toRadians(mc.options.fov().get());
        double r = Math.tan(Math.toRadians(ModuleManager.MACE_FOV.value)) / Math.tan(vfov / 2.0) * (h / 2.0);
        r = Mth.clamp(r, 3.0, h * 3.0);

        int cx = w / 2, cy = h / 2;
        int n = Math.max(48, (int) (r * 3));
        Setting.Color col = ModuleManager.MACE_COLOR;
        if (col.a <= 0.01f) return; // โปร่งใสสุด = ซ่อนวง

        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n;
            int x = cx + (int) Math.round(Math.cos(a) * r);
            int y = cy + (int) Math.round(Math.sin(a) * r);
            if (x < -2 || y < -2 || x > w + 2 || y > h + 2) continue;
            ctx.fill(x - 1, y - 1, x + 1, y + 1, col.argb(i / (double) n));
        }
    }
}
