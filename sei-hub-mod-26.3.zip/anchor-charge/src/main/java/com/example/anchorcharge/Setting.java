package com.example.anchorcharge;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;

import java.util.concurrent.ThreadLocalRandom;

/** ค่าตั้งของโมดูล (แสดงในหน้าต่างที่คลิกขวา) */
public abstract class Setting {
    public final String name;

    protected Setting(String name) {
        this.name = name;
    }

    /** สวิตช์ เปิด/ปิด */
    public static final class Toggle extends Setting {
        public boolean value;

        public Toggle(String name, boolean value) {
            super(name);
            this.value = value;
        }
    }

    /** ปุ่มสลับตัวเลือก */
    public static final class Mode extends Setting {
        public final String[] options;
        public int index;

        public Mode(String name, String[] options, int index) {
            super(name);
            this.options = options;
            this.index = index;
        }

        public String get() { return options[index]; }
        public void next() { index = (index + 1) % options.length; }
    }

    /** สี: วงสี (hue) + โทนสว่าง/มืด (s,v) + ความโปร่งใส (a) + เรนโบว์ */
    public static final class Color extends Setting {
        public float h, s, v, a;
        public boolean rainbow;

        public Color(String name, float h, float s, float v, float a, boolean rainbow) {
            super(name);
            this.h = h;
            this.s = s;
            this.v = v;
            this.a = a;
            this.rainbow = rainbow;
        }

        public int argb() { return argb(0); }

        /** phase ใช้เลื่อนเฉดเรนโบว์ให้ต่างกันในแต่ละจุด/เอนทิตี */
        public int argb(double phase) {
            float hue = h;
            if (rainbow) hue = (float) (((System.currentTimeMillis() % 4000L) / 4000.0 + phase) % 1.0);
            int rgb = net.minecraft.util.Mth.hsvToRgb(hue, s, v);
            return (Math.round(a * 255f) << 24) | (rgb & 0xFFFFFF);
        }
    }

    /** ตัวเลือกสีที่แก้สีของ 'รายการที่เลือกอยู่' (เช่น สีของมอนแต่ละตัว) */
    public static final class MobColor extends Setting {
        public final Mode sel;
        public final Color[] colors;

        public MobColor(String name, Mode sel, Color[] colors) {
            super(name);
            this.sel = sel;
            this.colors = colors;
        }

        public Color current() { return colors[sel.index]; }
    }

    /** เลือกได้หลายอัน (ชิปกดเปิด/ปิดทีละอัน) */
    public static final class Multi extends Setting {
        public final String[] options;
        public final boolean[] on;

        public Multi(String name, String[] options, boolean[] on) {
            super(name);
            this.options = options;
            this.on = on;
        }
    }

    /** สไลเดอร์ค่าเดียว */
    public static final class Slider extends Setting {
        public final double min, max, step;
        public double value;

        public Slider(String name, double min, double max, double step, double value) {
            super(name);
            this.min = min;
            this.max = max;
            this.step = step;
            this.value = value;
        }
    }

    /** สไลเดอร์ช่วง จาก lo ถึง hi */
    public static final class Range extends Setting {
        public final double min, max, step;
        public double lo, hi;

        public Range(String name, double min, double max, double step, double lo, double hi) {
            super(name);
            this.min = min;
            this.max = max;
            this.step = step;
            this.lo = lo;
            this.hi = hi;
        }

        /** สุ่มเวลาในช่วง lo-hi (ms) แล้วแปลงเป็น tick */
        public int randomTicks() {
            double ms = lo >= hi ? lo : ThreadLocalRandom.current().nextDouble(lo, hi);
            return (int) Math.ceil(ms / 50.0);
        }
    }

    /** ตั้งปุ่ม: คีย์บอร์ด หรือปุ่มเมาส์ (code >= 1000 = ปุ่มเมาส์ code-1000) ; -1 = ไม่ตั้ง */
    public static final class Key extends Setting {
        public int code;

        public Key(String name, int code) {
            super(name);
            this.code = code;
        }

        public boolean isDown() {
            if (code < 0) return false;
            Minecraft mc = Minecraft.getInstance();
            if (mc.getWindow() == null) return false;
            // 26.3: ไม่มี GLFW แล้ว (ใช้ SDL) -> อ่านผ่าน InputConstants / MouseHandler ของเกม
            if (code >= 1000) {
                switch (code - 1000) {
                    case 0: return mc.mouseHandler.isLeftPressed();
                    case 1: return mc.mouseHandler.isRightPressed();
                    case 2: return mc.mouseHandler.isMiddlePressed();
                    default: return false;
                }
            }
            return InputConstants.isKeyDown(code);
        }

        public String label() {
            if (code < 0) return Lang.t("None");
            if (code == 1000) return Lang.t("Left Click");
            if (code == 1001) return Lang.t("Right Click");
            if (code >= 1000) return "Mouse " + (code - 1000 + 1);
            if (code >= InputConstants.KEY_F1 && code <= InputConstants.KEY_F12) return "F" + (code - InputConstants.KEY_F1 + 1);
            if (code >= 65 && code <= 90) return String.valueOf((char) code);
            if (code >= 48 && code <= 57) return String.valueOf((char) code);
            switch (code) {
                case InputConstants.KEY_SPACE: return "Space";
                case InputConstants.KEY_LSHIFT: return "L-Shift";
                case InputConstants.KEY_RSHIFT: return "R-Shift";
                case InputConstants.KEY_LCONTROL: return "L-Ctrl";
                case InputConstants.KEY_RCONTROL: return "R-Ctrl";
                case InputConstants.KEY_LALT: return "L-Alt";
                case InputConstants.KEY_RALT: return "R-Alt";
                case InputConstants.KEY_TAB: return "Tab";
                case InputConstants.KEY_CAPSLOCK: return "Caps";
                case InputConstants.KEY_RETURN: return "Enter";
                case InputConstants.KEY_UP: return "Up";
                case InputConstants.KEY_DOWN: return "Down";
                case InputConstants.KEY_LEFT: return "Left";
                case InputConstants.KEY_RIGHT: return "Right";
                default: return "Key " + code;
            }
        }
    }
}
