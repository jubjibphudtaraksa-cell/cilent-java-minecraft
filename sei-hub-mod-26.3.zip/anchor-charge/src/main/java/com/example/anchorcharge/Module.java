package com.example.anchorcharge;

import java.util.ArrayList;
import java.util.List;

/** โมดูล 1 ตัวใน UI (functional=false คือมีแค่ปุ่มใน UI ยังไม่มีฟังก์ชันจริง) */
public final class Module {
    public final String name;
    public final String desc;
    public final boolean functional;
    public boolean enabled = false;
    public final List<Setting> settings = new ArrayList<>();

    public Module(String name, String desc, boolean functional) {
        this.name = name;
        this.desc = desc;
        this.functional = functional;
    }

    public void toggle() {
        enabled = !enabled;
    }
}
