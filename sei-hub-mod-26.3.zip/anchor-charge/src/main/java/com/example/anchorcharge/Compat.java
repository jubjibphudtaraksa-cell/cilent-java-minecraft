package com.example.anchorcharge;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.LivingEntity;

import java.lang.reflect.Method;

/** ตัวช่วยกัน API ที่เปลี่ยนบ่อยระหว่างเวอร์ชัน Minecraft (ใช้ reflection) */
public final class Compat {
    private Compat() {}

    /** แกว่งแขน ไม่ว่า swing() จะมีกี่พารามิเตอร์ */
    public static void swing(LivingEntity e, InteractionHand hand) {
        try {
            Method three = null;
            for (Method m : e.getClass().getMethods()) {
                if (!m.getName().equals("swing")) continue;
                Class<?>[] t = m.getParameterTypes();
                if (t.length == 1 && t[0] == InteractionHand.class) {
                    m.invoke(e, hand);
                    return;
                }
                if (t.length == 3 && t[0] == InteractionHand.class && t[2] == boolean.class) three = m;
            }
            if (three != null) {
                Object anim = defaultValue(three.getParameterTypes()[1]);
                three.invoke(e, hand, anim, true);
            }
        } catch (Throwable ignored) {
            // แกว่งแขนเป็นแค่ภาพ ไม่ให้เกมล่มถ้าเรียกไม่ได้
        }
    }

    /** คลิกช่อง inventory แบบ SWAP (ชื่อเมธอด/enum เปลี่ยนไปในเวอร์ชันใหม่) */
    public static void swapClick(Object gameMode, Object player, int containerId, int slot, int button) {
        try {
            for (Method m : gameMode.getClass().getMethods()) {
                Class<?>[] t = m.getParameterTypes();
                if (t.length != 5 || !m.getName().startsWith("handle")) continue;
                if (t[0] != int.class || t[1] != int.class || t[2] != int.class) continue;
                if (!t[3].isEnum() || !t[4].isInstance(player)) continue;
                Object swap = null;
                for (Object c : t[3].getEnumConstants()) {
                    if (c.toString().equals("SWAP")) swap = c;
                }
                if (swap == null) continue;
                m.invoke(gameMode, containerId, slot, button, swap, player);
                return;
            }
        } catch (Throwable ignored) {
        }
    }

    private static Object defaultValue(Class<?> type) throws Exception {
        if (type.isEnum()) {
            Object[] all = type.getEnumConstants();
            for (Object c : all) {
                if (c.toString().equals("WHACK")) return c;
            }
            return all.length > 0 ? all[0] : null;
        }
        for (var f : type.getFields()) {
            if (java.lang.reflect.Modifier.isStatic(f.getModifiers()) && f.getType() == type) return f.get(null);
        }
        return null;
    }
}
