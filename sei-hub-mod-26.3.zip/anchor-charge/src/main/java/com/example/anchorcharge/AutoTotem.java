package com.example.anchorcharge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.item.Items;
import net.minecraft.world.inventory.ClickType;

/**
 * ถ้ามือรองว่าง -> ย้าย Totem จากกระเป๋าเข้ามือรอง
 */
public final class AutoTotem {
    private static int waiting = -1;  // -1 = ยังไม่เริ่มนับ
    private static int cooldown = 0;  // พักหลังคลิก ให้เซิร์ฟเวอร์ซิงค์

    private AutoTotem() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoTotem::tick);
    }

    private static void tick(Minecraft mc) {
        LocalPlayer player = mc.player;
        if (!ModuleManager.AUTO_TOTEM.enabled || player == null || mc.gameMode == null) {
            waiting = -1;
            return;
        }
        if (cooldown > 0) { cooldown--; return; }

        boolean inventoryMode = ModuleManager.TOTEM_MODE.index == 0;
        boolean invOpen = mc.gui.screen() instanceof InventoryScreen;
        if (inventoryMode ? !invOpen : mc.gui.screen() != null) {
            waiting = -1;
            return;
        }

        if (player.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) {
            waiting = -1;
            return;
        }

        int slot = -1;
        for (int i = 0; i < 36; i++) {
            if (player.getInventory().getItem(i).is(Items.TOTEM_OF_UNDYING)) {
                slot = i < 9 ? 36 + i : i; // ช่อง hotbar ใน screen handler = 36-44
                break;
            }
        }
        if (slot < 0) {
            waiting = -1;
            return;
        }

        if (waiting < 0) waiting = ModuleManager.TOTEM_DELAY.randomTicks();
        if (waiting > 0) {
            waiting--;
            return;
        }

        // SWAP กับปุ่ม 40 = สลับกับมือรอง
        mc.gameMode.handleInventoryMouseClick(player.inventoryMenu.containerId, slot, 40,
                ClickType.SWAP, player);
        waiting = -1;
        cooldown = 2;
    }
}
