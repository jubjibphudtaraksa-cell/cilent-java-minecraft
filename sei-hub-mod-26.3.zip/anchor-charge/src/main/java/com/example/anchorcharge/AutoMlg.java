package com.example.anchorcharge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Predicate;

/**
 * Auto MLG: ตกจากที่สูง -> ก่อนถึงพื้น
 *  - Water MLG: วางน้ำจากถัง แล้วเก็บน้ำคืนตอนลงถึงพื้น
 *  - Slime Block MLG: วางสไลม์บล็อกใต้เท้า
 *  - Boat MLG: วางเรือแล้วนั่ง (ลงจากเรือให้ตอนถึงพื้น)
 * ลำดับความสำคัญ: น้ำ > สไลม์ > เรือ (เลือกเฉพาะอันที่เปิดไว้และมีของอยู่ใน hotbar/มือรอง)
 */
public final class AutoMlg {
    private enum Phase { IDLE, WATER, BOAT }

    private static final double MIN_FALL = 3.0;     // ตกเกินกี่บล็อกถึงจะทำงาน
    private static final double REACH_HEIGHT = 2.85; // สูงจากพื้นไม่เกินนี้ถึงวางได้ (ระยะเอื้อมจากตา)

    private static Phase phase = Phase.IDLE;
    private static double peakY = 0;
    private static boolean armed = true;
    private static int t = 0;
    private static int prevSlot = -1;
    private static InteractionHand mlgHand = InteractionHand.MAIN_HAND;
    private static int mlgSlot = -1;
    private static boolean sneaking = false;
    private static int seated = 0;                       // นั่งเรืออยู่กี่แท็ก
    private static final Set<Integer> oldBoats = new HashSet<>(); // เรือที่มีอยู่ก่อนวาง (ไม่นับ)

    private AutoMlg() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoMlg::tick);
    }

    private static void finish(Minecraft mc, LocalPlayer p) {
        if (sneaking) {
            mc.options.keyShift.setDown(false);
            sneaking = false;
        }
        if (p != null) {
            if (prevSlot >= 0) p.getInventory().setSelectedSlot(prevSlot);
        }
        prevSlot = -1;
        mlgSlot = -1;
        seated = 0;
        oldBoats.clear();
        phase = Phase.IDLE;
    }

    private static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        ClientLevel w = mc.level;
        if (!ModuleManager.AUTO_MLG.enabled || p == null || w == null || mc.gameMode == null) {
            if (phase != Phase.IDLE) finish(mc, p);
            return;
        }

        if (phase == Phase.WATER) { waterPickup(mc, p); return; }
        if (phase == Phase.BOAT) { boatPhase(mc, w, p); return; }

        // ===== IDLE: ตรวจว่ากำลังตกอยู่ไหม =====
        boolean safe = p.onGround() || p.isInWater() || p.isPassenger()
                || p.getAbilities().flying || p.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA);
        if (safe) {
            peakY = p.getY();
            armed = true;
            return;
        }
        peakY = Math.max(peakY, p.getY());
        if (!armed) return;
        if (peakY - p.getY() < MIN_FALL || p.getDeltaMovement().y > -0.3) return;

        BlockPos[] ground = new BlockPos[1];
        double h = heightAboveGround(w, p, ground);
        if (h < 0 || h > REACH_HEIGHT) return;

        if (ModuleManager.MLG_WATER.value && tryWater(mc, p)) { armed = false; return; }
        // สไลม์ต้องวางตอนเท้ายังอยู่เหนือช่องที่จะวาง (ไม่งั้นชนตัวผู้เล่น)
        if (ModuleManager.MLG_SLIME.value && h >= 1.05 && trySlime(mc, p, ground[0])) { armed = false; return; }
        if (ModuleManager.MLG_BOAT.value && tryBoat(mc, p)) { armed = false; }
    }

    /**
     * Silent rotation: ตั้ง pitch เป็น 90 (มองลง) เฉพาะตอนส่งแพ็กเก็ตใช้ไอเท็ม
     * แล้วคืนค่าเดิมทันทีในแท็กเดียวกัน -> เซิร์ฟเวอร์เห็นว่าเราหันลง
     * แต่กล้อง/มุมมองฝั่งเราไม่ขยับเลย (เรนเดอร์เกิดหลังจบแท็ก)
     * ไม่แตะ prevPitch/prevYaw เพื่อไม่ให้ภาพกระตุก
     */
    private static void useItemSilent(Minecraft mc, LocalPlayer p, InteractionHand hand) {
        Rot.silent(mc, p, p.getYRot(), 90f, () -> mc.gameMode.useItem(p, hand));
        p.swing(hand);
    }

    /** ระยะจากเท้าถึงบล็อกแข็งที่อยู่ข้างล่าง ; -1 = ไม่เจอ หรือข้างล่างเป็นของเหลว (ลงน้ำอยู่แล้ว) */
    private static double heightAboveGround(ClientLevel w, LocalPlayer p, BlockPos[] out) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        int x = Mth.floor(p.getX());
        int z = Mth.floor(p.getZ());
        int startY = Mth.floor(p.getY());
        for (int y = startY; y >= startY - 8; y--) {
            pos.set(x, y, z);
            BlockState st = w.getBlockState(pos);
            if (!st.getFluidState().isEmpty()) return -1;
            if (!st.getCollisionShape(w, pos).isEmpty()) {
                out[0] = pos.immutable();
                return p.getY() - (y + 1);
            }
        }
        return -1;
    }

    /** หาของใน มือรอง/hotbar ; ถ้าเจอใน hotbar จะสลับช่องให้ */
    private static InteractionHand pick(LocalPlayer p, Predicate<ItemStack> f) {
        if (f.test(p.getOffhandItem())) {
            mlgSlot = -1;
            return InteractionHand.OFF_HAND;
        }
        for (int i = 0; i < 9; i++) {
            if (f.test(p.getInventory().getItem(i))) {
                prevSlot = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(i);
                mlgSlot = i;
                return InteractionHand.MAIN_HAND;
            }
        }
        return null;
    }

    private static boolean isBoat(ItemStack s) {
        if (s.isEmpty()) return false;
        String path = BuiltInRegistries.ITEM.getKey(s.getItem()).getPath();
        return path.endsWith("_boat") || path.endsWith("_raft");
    }

    // ===== น้ำ =====
    private static boolean tryWater(Minecraft mc, LocalPlayer p) {
        InteractionHand h = pick(p, s -> s.is(Items.WATER_BUCKET));
        if (h == null) return false;
        mlgHand = h;
        useItemSilent(mc, p, h); // หันลงพื้นฝั่งเซิร์ฟเวอร์ แต่กล้องเราไม่หัน
        phase = Phase.WATER;
        t = 0;
        return true;
    }

    private static void waterPickup(Minecraft mc, LocalPlayer p) {
        t++;
        if (t > 60) { finish(mc, p); return; }
        if (t < 3 || !(p.onGround() || p.isInWater())) return;

        ItemStack st = mlgHand == InteractionHand.OFF_HAND ? p.getOffhandItem() : p.getInventory().getItem(mlgSlot);
        if (st.is(Items.WATER_BUCKET)) { finish(mc, p); return; } // เก็บน้ำกลับมาแล้ว (หรือวางไม่สำเร็จ)
        if (!st.is(Items.BUCKET)) { finish(mc, p); return; }

        if (mlgHand == InteractionHand.MAIN_HAND) p.getInventory().setSelectedSlot(mlgSlot);
        useItemSilent(mc, p, mlgHand); // ถังเปล่า -> เก็บน้ำ
    }

    // ===== สไลม์ =====
    private static boolean trySlime(Minecraft mc, LocalPlayer p, BlockPos ground) {
        InteractionHand h = pick(p, s -> s.is(Items.SLIME_BLOCK));
        if (h == null) return false;
        BlockHitResult top = new BlockHitResult(Vec3.atCenterOf(ground).add(0, 0.5, 0), Direction.UP, ground, false);
        Rot.silentAt(mc, p, top.getPos(), () -> mc.gameMode.useItemOn(p, h, top)); // หันฝั่งเซิร์ฟเวอร์ไปที่บล็อก
        p.swing(h);
        finish(mc, p); // คืนช่องเดิมทันที
        return true;
    }

    // ===== เรือ =====
    private static boolean tryBoat(Minecraft mc, LocalPlayer p) {
        InteractionHand h = pick(p, AutoMlg::isBoat);
        if (h == null) return false;
        mlgHand = h;
        oldBoats.clear();
        for (Entity e : mc.level.getEntities(p, p.getBoundingBox().inflate(8, 8, 8))) {
            if (isBoatEntity(e)) oldBoats.add(e.getId());
        }
        seated = 0;
        useItemSilent(mc, p, h);
        phase = Phase.BOAT;
        t = 0;
        return true;
    }

    private static boolean isBoatEntity(Entity e) {
        String path = BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath();
        return path.endsWith("boat") || path.endsWith("raft");
    }

    /** เรือที่เพิ่งโผล่ (ไม่ใช่เรือเก่า) และยังไม่มีคนนั่ง ที่ใกล้เราสุด */
    private static Entity nearestNewBoat(ClientLevel w, LocalPlayer p) {
        Entity best = null;
        double bd = Double.MAX_VALUE;
        for (Entity e : w.getEntities(p, p.getBoundingBox().inflate(8, 8, 8))) {
            if (!isBoatEntity(e) || e.isVehicle() || oldBoats.contains(e.getId())) continue;
            double d = e.distanceToSqr(p);
            if (d < bd) { bd = d; best = e; }
        }
        return best;
    }

    private static void boatPhase(Minecraft mc, ClientLevel w, LocalPlayer p) {
        t++;
        if (t > 80) { finish(mc, p); return; }

        if (!p.isPassenger()) {
            if (sneaking || seated > 0) { finish(mc, p); return; } // ลงจากเรือเรียบร้อย
            Entity boat = nearestNewBoat(w, p);
            if (boat != null) {
                // ยกเลิก Shift ก่อน ไม่งั้นเซิร์ฟเวอร์ไม่ยอมให้นั่ง (ย่อตัว = ไม่ใช่การกดใช้)
                if (p.isShiftKeyDown()) mc.options.keyShift.setDown(false);
                final Entity b = boat;
                Rot.silentAt(mc, p, b.getBoundingBox().getCenter(),
                        () -> mc.gameMode.interact(p, b, mlgHand)); // นั่งเรือ (ลองซ้ำทุกแท็ก)
            }
            return;
        }

        seated++;
        Entity v = p.getVehicle();
        // นั่งอยู่ให้ครบอย่างน้อย 6 แท็กก่อน (เรือเกิดบนพื้นอยู่แล้ว ถ้าเช็กทันทีจะลงเรือเองทันที)
        if (seated >= 6 && v != null && (v.onGround() || v.isInWater())) {
            mc.options.keyShift.setDown(true); // กด Shift ลงจากเรือ
            sneaking = true;
        }
    }
}
