package com.example.anchorcharge;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/** ตัวช่วย silent rotation: ส่งมุมให้เซิร์ฟเวอร์ โดยไม่แตะมุมกล้องฝั่งเรา */
public final class Rot {
    private Rot() {}

    /** ส่งมุมมองปลอมให้เซิร์ฟเวอร์ (กล้องเราไม่เปลี่ยน) */
    public static void send(Minecraft mc, LocalPlayer p, float yaw, float pitch) {
        if (mc.getConnection() == null) return;
        mc.getConnection().send(
                new ServerboundMovePlayerPacket.Rot(yaw, pitch, p.onGround(), p.horizontalCollision));
    }

    /** ส่งมุมจริงของเรากลับไปให้เซิร์ฟเวอร์ */
    public static void syncReal(Minecraft mc, LocalPlayer p) {
        send(mc, p, p.getYRot(), p.getXRot());
    }

    /**
     * รันการกระทำ (วาง/ใช้/นั่ง/ตี) โดยหันฝั่งเซิร์ฟเวอร์ไปทาง yaw/pitch ที่ระบุ
     * แล้วคืนมุมกล้องจริงทันทีในแท็กเดียวกัน -> กล้อง/เมาส์เรา ไม่ถูกแตะเลย
     */
    public static void silent(Minecraft mc, LocalPlayer p, float yaw, float pitch, Runnable action) {
        float oldYaw = p.getYRot(), oldPitch = p.getXRot();
        p.setYRot(yaw);
        p.setXRot(pitch);
        send(mc, p, yaw, pitch);
        try {
            action.run();
        } finally {
            p.setYRot(oldYaw);
            p.setXRot(oldPitch);
            syncReal(mc, p);
        }
    }

    /** เหมือน silent() แต่หันไปหาจุดในโลก */
    public static void silentAt(Minecraft mc, LocalPlayer p, Vec3 target, Runnable action) {
        Vec3 eye = p.getEyePosition();
        silent(mc, p, yawTo(eye, target), pitchTo(eye, target), action);
    }

    public static float yawTo(Vec3 from, Vec3 to) {
        return Mth.wrapDegrees((float) (Math.toDegrees(Math.atan2(to.z - from.z, to.x - from.x)) - 90.0));
    }

    public static float pitchTo(Vec3 from, Vec3 to) {
        double dx = to.x - from.x, dz = to.z - from.z;
        return Mth.clamp((float) -Math.toDegrees(Math.atan2(to.y - from.y, Math.sqrt(dx * dx + dz * dz))), -90f, 90f);
    }
}
