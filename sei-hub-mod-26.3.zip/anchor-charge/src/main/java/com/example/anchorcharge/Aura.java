package com.example.anchorcharge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.AABB;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

import java.util.function.Predicate;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Kill Aura (ผู้เล่นเท่านั้น) และ Mob Aura (มอนที่เลือกไว้)
 * ตีเป้าที่ใกล้สุดในระยะ ตามช่วง CPS ; Silent Aim = หันฝั่งเซิร์ฟเวอร์ไปหาเป้า กล้องเราไม่ขยับ
 */
public final class Aura {
    private static long nextKill = 0;
    private static long nextMob = 0;

    private Aura() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(Aura::tick);
    }

    private static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null
                || mc.gui.screen() != null || p.isUsingItem() || !p.isAlive()) return;

        long now = System.currentTimeMillis();

        if (ModuleManager.KILL_AURA.enabled && now >= nextKill) {
            Entity t = nearest(mc, p, ModuleManager.KA_RANGE.value,
                    e -> e instanceof Player o && !o.isSpectator());
            if (t != null) {
                nextKill = now + interval(ModuleManager.KA_CPS);
                hit(mc, p, t, ModuleManager.KA_SILENT.value);
            }
        }

        if (ModuleManager.MOB_AURA.enabled && now >= nextMob) {
            Entity t = nearest(mc, p, ModuleManager.MOB_RANGE.value, Aura::isPickedMob);
            if (t != null) {
                nextMob = now + interval(ModuleManager.MOB_CPS);
                hit(mc, p, t, ModuleManager.MOB_SILENT.value);
            }
        }
    }

    private static boolean isPickedMob(Entity e) {
        if (!(e instanceof LivingEntity) || e instanceof Player) return false;
        String path = BuiltInRegistries.ENTITY_TYPE.getKey(e.getType()).getPath();
        Setting.Multi m = ModuleManager.MOB_TYPES;
        for (int i = 0; i < m.on.length; i++) {
            if (!m.on[i]) continue;
            for (String id : ModuleManager.MOB_IDS[i]) {
                if (id.equals(path)) return true;
            }
        }
        return false;
    }

    /** ระยะห่างระหว่างตัวตี (ms) จากช่วง CPS แบบสุ่ม */
    private static long interval(Setting.Range cps) {
        double rate = cps.lo >= cps.hi ? cps.lo : ThreadLocalRandom.current().nextDouble(cps.lo, cps.hi);
        return (long) (1000.0 / Math.max(1.0, rate));
    }

    /** เป้าที่ใกล้ที่สุดในระยะ และมองเห็น (ไม่ทะลุกำแพง) */
    private static Entity nearest(Minecraft mc, LocalPlayer p, double range, Predicate<Entity> filter) {
        Vec3 eye = p.getEyePosition();
        Entity best = null;
        double bd = range * range;
        for (Entity e : mc.level.getEntities(p, p.getBoundingBox().inflate(range + 1.0),
                x -> x.isAlive() && filter.test(x))) {
            AABB b = e.getBoundingBox();
            Vec3 near = new Vec3(
                    Mth.clamp(eye.x, b.minX, b.maxX),
                    Mth.clamp(eye.y, b.minY, b.maxY),
                    Mth.clamp(eye.z, b.minZ, b.maxZ));
            double d = eye.distanceToSqr(near);
            if (d <= bd && p.hasLineOfSight(e)) {
                bd = d;
                best = e;
            }
        }
        return best;
    }

    private static void hit(Minecraft mc, LocalPlayer p, Entity t, boolean silent) {
        Runnable attack = () -> mc.gameMode.attack(p, t);
        if (silent) Rot.silentAt(mc, p, t.getBoundingBox().getCenter(), attack);
        else attack.run();
        p.swing(InteractionHand.MAIN_HAND);
    }
}
