package com.example.anchorcharge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.item.Items;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.core.Direction;
import net.minecraft.world.phys.Vec3;

/**
 * ถือคริสตัลค้างปุ่มที่ตั้งไว้ แล้ววนต่อเนื่อง:
 *  เล็งบล็อก Obsidian/Bedrock -> วาง -> ตี -> วางซ้ำที่เดิมทันที (ไม่ต้องรอคริสตัลเก่าหายจากฝั่งเรา) -> ...
 */
public final class AutoCrystal {
    private static long age = 0;
    private static int placeWait = -1;
    private static int hitWait = -1;
    private static BlockPos pendingBase = null; // ฐานที่เพิ่งตีคริสตัลไป รอวางซ้ำ
    private static int lastHitId = -1;          // คริสตัลที่เพิ่งตี (ข้ามไม่ตีซ้ำ)
    private static BlockPos placedPos = null;   // ตำแหน่งที่เพิ่งวาง รอคริสตัลโผล่
    private static long placedAt = -100;

    private AutoCrystal() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoCrystal::tick);
    }

    private static void reset() {
        placeWait = -1;
        hitWait = -1;
        pendingBase = null;
    }

    private static boolean validBase(ClientLevel w, BlockPos p) {
        return w.getBlockState(p).is(Blocks.OBSIDIAN) || w.getBlockState(p).is(Blocks.BEDROCK);
    }

    private static void tick(Minecraft mc) {
        age++;
        LocalPlayer player = mc.player;
        ClientLevel world = mc.level;
        if (!ModuleManager.AUTO_CRYSTAL.enabled || player == null || world == null
                || mc.gameMode == null || mc.gui.screen() != null
                || !ModuleManager.CRYSTAL_KEY.isDown()) {
            reset();
            return;
        }

        InteractionHand hand;
        if (player.getMainHandItem().is(Items.END_CRYSTAL)) hand = InteractionHand.MAIN_HAND;
        else if (player.getOffhandItem().is(Items.END_CRYSTAL)) hand = InteractionHand.OFF_HAND;
        else { reset(); return; }

        // 1) เพิ่งตีคริสตัลไป -> วางซ้ำที่ฐานเดิม (เซิร์ฟเวอร์ลบคริสตัลเก่าแล้ว)
        if (pendingBase != null) {
            if (!validBase(world, pendingBase)) {
                pendingBase = null;
            } else {
                if (placeWait < 0) placeWait = ModuleManager.CRYSTAL_PLACE.randomTicks();
                if (placeWait > 0) { placeWait--; return; }
                BlockHitResult top = new BlockHitResult(
                        Vec3.atCenterOf(pendingBase).add(0, 0.5, 0), Direction.UP, pendingBase, false);
                mc.gameMode.useItemOn(player, hand, top);
                Compat.swing(player, hand);
                placedPos = pendingBase.above();
                placedAt = age;
                pendingBase = null;
                placeWait = -1;
                return;
            }
        }

        HitResult hr = mc.hitResult;

        // 2) เล็งโดนคริสตัล -> ตี
        if (hr instanceof EntityHitResult ehr && ehr.getEntity() instanceof EndCrystal crystal
                && crystal.getId() != lastHitId) {
            placeWait = -1;
            if (hitWait < 0) hitWait = ModuleManager.CRYSTAL_HIT.randomTicks();
            if (hitWait > 0) { hitWait--; return; }
            mc.gameMode.attack(player, crystal);
            Compat.swing(player, InteractionHand.MAIN_HAND);
            lastHitId = crystal.getId();
            hitWait = -1;
            BlockPos base = crystal.blockPosition().below();
            if (validBase(world, base)) pendingBase = base;
            return;
        }
        hitWait = -1;

        // 3) เล็งบล็อกที่วางได้ -> วางคริสตัล
        if (hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
            BlockPos base = bhr.getBlockPos();
            BlockPos above = base.above();
            // เพิ่งวางไป รอให้คริสตัลโผล่ก่อน (กันวางซ้ำเพราะปิง)
            if (above.equals(placedPos) && age - placedAt < 8) return;
            boolean free = world.isEmptyBlock(above) && world.getEntities(null, new AABB(above)).isEmpty();
            if (validBase(world, base) && free) {
                if (placeWait < 0) placeWait = ModuleManager.CRYSTAL_PLACE.randomTicks();
                if (placeWait > 0) { placeWait--; return; }
                mc.gameMode.useItemOn(player, hand, bhr);
                Compat.swing(player, hand);
                placedPos = above;
                placedAt = age;
                placeWait = -1;
                return;
            }
        }
        placeWait = -1;
    }
}
