package com.example.anchorcharge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.function.Predicate;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Kill Aura (ผู้เล่นเท่านั้น) และ Mob Aura (มอนที่เลือกไว้)
 * ตีเป้าที่ใกล้สุดในระยะ ตามช่วง CPS ; Silent Aim = หันฝั่งเซิร์ฟเวอร์ไปหาเป้า กล้องเราไม่ขยับ
 */
public final class Aura {
    private static long nextKill = 0;
    private static long nextMob = 0;

    private Aura() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(Aura::tick);
    }

    private static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null
                || mc.currentScreen != null || p.isUsingItem() || !p.isAlive()) return;

        long now = System.currentTimeMillis();

        if (ModuleManager.KILL_AURA.enabled && now >= nextKill) {
            Entity t = nearest(mc, p, ModuleManager.KA_RANGE.value,
                    e -> e instanceof PlayerEntity o && !o.isSpectator());
            if (t != null) {
                nextKill = now + interval(ModuleManager.KA_CPS);
                hit(mc, p, t, ModuleManager.KA_SILENT.value);
            }
        }

        if (ModuleManager.MOB_AURA.enabled && now >= nextMob) {
            Entity t = nearest(mc, p, ModuleManager.MOB_RANGE.value, Aura::isPickedMob);
            if (t != null) {
                nextMob = now + interval(ModuleManager.MOB_CPS);
                hit(mc, p, t, ModuleManager.MOB_SILENT.value);
            }
        }
    }

    private static boolean isPickedMob(Entity e) {
        if (!(e instanceof LivingEntity) || e instanceof PlayerEntity) return false;
        String path = Registries.ENTITY_TYPE.getId(e.getType()).getPath();
        Setting.Multi m = ModuleManager.MOB_TYPES;
        for (int i = 0; i < m.on.length; i++) {
            if (!m.on[i]) continue;
            for (String id : ModuleManager.MOB_IDS[i]) {
                if (id.equals(path)) return true;
            }
        }
        return false;
    }

    /** ระยะห่างระหว่างตัวตี (ms) จากช่วง CPS แบบสุ่ม */
    private static long interval(Setting.Range cps) {
        double rate = cps.lo >= cps.hi ? cps.lo : ThreadLocalRandom.current().nextDouble(cps.lo, cps.hi);
        return (long) (1000.0 / Math.max(1.0, rate));
    }

    /** เป้าที่ใกล้ที่สุดในระยะ และมองเห็น (ไม่ทะลุกำแพง) */
    private static Entity nearest(MinecraftClient mc, ClientPlayerEntity p, double range, Predicate<Entity> filter) {
        Vec3d eye = p.getEyePos();
        Entity best = null;
        double bd = range * range;
        for (Entity e : mc.world.getOtherEntities(p, p.getBoundingBox().expand(range + 1.0),
                x -> x.isAlive() && filter.test(x))) {
            Box b = e.getBoundingBox();
            Vec3d near = new Vec3d(
                    MathHelper.clamp(eye.x, b.minX, b.maxX),
                    MathHelper.clamp(eye.y, b.minY, b.maxY),
                    MathHelper.clamp(eye.z, b.minZ, b.maxZ));
            double d = eye.squaredDistanceTo(near);
            if (d <= bd && p.canSee(e)) {
                bd = d;
                best = e;
            }
        }
        return best;
    }

    private static void hit(MinecraftClient mc, ClientPlayerEntity p, Entity t, boolean silent) {
        Runnable attack = () -> mc.interactionManager.attackEntity(p, t);
        if (silent) Rot.silentAt(mc, p, t.getBoundingBox().getCenter(), attack);
        else attack.run();
        p.swingHand(Hand.MAIN_HAND);
    }
}
