package com.example.anchorcharge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** คลิกขวาถือ End Crystal ที่ Obsidian/Bedrock -> วางแล้วทุบคริสตัลให้ (หน่วงเวลาสุ่มทุกครั้ง) */
public final class FashCyClient {
    private static final int MAX_WAIT_TICKS = 10;
    private static final int MIN_DELAY = 10; // tick
    private static final int MAX_DELAY = 50; // tick

    private static BlockPos pending = null;
    private static int waited = 0;
    private static int delay = -1;

    private FashCyClient() {}

    public static void init() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!ModuleManager.FASHCY.enabled || !world.isClient()) return ActionResult.PASS;
            if (!player.getStackInHand(hand).isOf(Items.END_CRYSTAL)) return ActionResult.PASS;

            BlockPos base = hit.getBlockPos();
            BlockState st = world.getBlockState(base);
            if (!st.isOf(Blocks.OBSIDIAN) && !st.isOf(Blocks.BEDROCK)) return ActionResult.PASS;

            BlockPos above = base.up();
            if (!world.getEntitiesByClass(EndCrystalEntity.class, new Box(above),
                    e -> e.getBlockPos().equals(above)).isEmpty()) {
                return ActionResult.PASS;
            }

            pending = base;
            waited = 0;
            delay = -1;
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(FashCyClient::tick);
    }

    private static void tick(MinecraftClient mc) {
        if (pending == null) return;

        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;
        if (!ModuleManager.FASHCY.enabled || player == null || world == null || mc.interactionManager == null) {
            pending = null;
            return;
        }

        BlockPos above = pending.up();
        List<EndCrystalEntity> found = world.getEntitiesByClass(EndCrystalEntity.class, new Box(above),
                e -> e.isAlive() && e.getBlockPos().equals(above));

        if (found.isEmpty()) {
            if (delay >= 0 || ++waited > MAX_WAIT_TICKS) pending = null;
            return;
        }

        if (delay < 0) {
            delay = ThreadLocalRandom.current().nextInt(MIN_DELAY, MAX_DELAY + 1);
        }
        if (delay > 0) {
            delay--;
            return;
        }

        mc.interactionManager.attackEntity(player, found.get(0));
        player.swingHand(Hand.MAIN_HAND);
        pending = null;
    }
}
