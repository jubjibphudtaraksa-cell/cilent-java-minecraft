package com.example.anchorcharge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Auto Mace: ถือ Mace -> หาผู้เล่นในวง FOV รอบเป้าเล็ง -> หันไปหา (silent) -> ตีตาม CPS
 *  - Silent Aim: เซิร์ฟเวอร์เห็นว่าเราหันไปหาเป้า แต่กล้องเราไม่ขยับ (ส่งมุม -> ตี -> ส่งมุมจริงกลับ ในแท็กเดียว)
 *  - วงกลม FOV วาดบนจอ ปรับขนาด/สีได้ (มีสายรุ้ง)
 */
public final class AutoMace {
    private static long nextAttack = 0;

    private AutoMace() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoMace::tick);
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR,
                Identifier.of("anchorcharge", "mace_fov"), AutoMace::renderHud);
    }

    private static boolean active(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        return ModuleManager.AUTO_MACE.enabled && p != null && mc.world != null
                && mc.interactionManager != null && mc.currentScreen == null
                && p.getMainHandStack().isOf(Items.MACE);
    }

    private static void tick(MinecraftClient mc) {
        if (!active(mc)) return;
        ClientPlayerEntity p = mc.player;

        long now = System.currentTimeMillis();
        if (now < nextAttack) return;

        PlayerEntity target = findTarget(mc.world, p, ModuleManager.MACE_FOV.value);
        if (target == null) return;

        Setting.Range cps = ModuleManager.MACE_CPS;
        double rate = cps.lo >= cps.hi ? cps.lo : ThreadLocalRandom.current().nextDouble(cps.lo, cps.hi);
        nextAttack = now + (long) (1000.0 / Math.max(1.0, rate));

        Vec3d eye = p.getEyePos();
        Vec3d aim = target.getBoundingBox().getCenter();
        boolean silent = ModuleManager.MACE_SILENT.value;

        if (silent) Rot.send(mc, p, Rot.yawTo(eye, aim), Rot.pitchTo(eye, aim)); // เซิร์ฟเวอร์เห็นว่าหันไปหาเป้า
        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
        if (silent) Rot.syncReal(mc, p); // คืนมุมจริง กล้องเราไม่เคยขยับ
    }

    /** ผู้เล่นที่อยู่ในวง FOV, อยู่ในระยะตี, มองเห็นได้ ; เลือกคนที่ใกล้เป้าเล็งที่สุด */
    private static PlayerEntity findTarget(ClientWorld w, ClientPlayerEntity p, double fovDeg) {
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1.0f).normalize();
        double reach = p.getEntityInteractionRange();
        PlayerEntity best = null;
        double bestAng = fovDeg;

        for (PlayerEntity o : w.getPlayers()) {
            if (o == p || !o.isAlive() || o.isSpectator()) continue;
            Box b = o.getBoundingBox();
            Vec3d near = new Vec3d(
                    MathHelper.clamp(eye.x, b.minX, b.maxX),
                    MathHelper.clamp(eye.y, b.minY, b.maxY),
                    MathHelper.clamp(eye.z, b.minZ, b.maxZ));
            if (eye.squaredDistanceTo(near) > reach * reach) continue;
            if (!p.canSee(o)) continue;

            Vec3d dir = b.getCenter().subtract(eye).normalize();
            double ang = Math.toDegrees(Math.acos(MathHelper.clamp(look.dotProduct(dir), -1.0, 1.0)));
            if (ang <= bestAng) {
                bestAng = ang;
                best = o;
            }
        }
        return best;
    }

    // ===== วงกลม FOV =====
    private static void renderHud(DrawContext ctx, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!ModuleManager.AUTO_MACE.enabled || !ModuleManager.MACE_CIRCLE.value
                || mc.player == null || mc.currentScreen != null || mc.options.hudHidden) return;

        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        double vfov = Math.toRadians(mc.options.getFov().getValue());
        double r = Math.tan(Math.toRadians(ModuleManager.MACE_FOV.value)) / Math.tan(vfov / 2.0) * (h / 2.0);
        r = MathHelper.clamp(r, 3.0, h * 3.0);

        int cx = w / 2, cy = h / 2;
        int n = Math.max(48, (int) (r * 3));
        Setting.Color col = ModuleManager.MACE_COLOR;
        if (col.a <= 0.01f) return; // โปร่งใสสุด = ซ่อนวง

        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n;
            int x = cx + (int) Math.round(Math.cos(a) * r);
            int y = cy + (int) Math.round(Math.sin(a) * r);
            if (x < -2 || y < -2 || x > w + 2 || y > h + 2) continue;
            ctx.fill(x - 1, y - 1, x + 1, y + 1, col.argb(i / (double) n));
        }
    }
}
