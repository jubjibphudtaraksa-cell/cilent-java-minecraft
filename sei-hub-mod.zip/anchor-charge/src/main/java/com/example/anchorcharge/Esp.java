package com.example.anchorcharge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * Mob ESP / Players ESP แบบวาด 2 มิติบนจอ (HUD) -> มองทะลุกำแพงได้
 * ฉายจุดในโลกลงจอเอง จากกล้อง (ตำแหน่ง/มุม/FOV) ไม่พึ่งระบบเรนเดอร์โลก
 * ตำแหน่งเอนทิตีถูกสอดแทรก (interpolate) ระหว่างแท็ก ภาพเลยไม่กระตุก
 */
public final class Esp {
    private static final Map<Integer, Vec3d[]> POS = new HashMap<>(); // id -> {แท็กก่อน, แท็กล่าสุด}
    private static Vec3d camPrev, camCur;
    private static long tickAt = System.nanoTime();
    private static float fovMul = 1f;

    // ค่ากล้องของเฟรมนี้
    private static double camX, camY, camZ, fx, fy, fz, rx, rz, ux, uy, uz, tanHalf, aspect;
    private static int sw, sh;

    private Esp() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(Esp::tick);
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR,
                Identifier.of("anchorcharge", "esp"), Esp::render);
    }

    // ===== เก็บตำแหน่งทุกแท็ก =====
    private static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null
                || !(ModuleManager.MOB_ESP.enabled || ModuleManager.PLAYER_ESP.enabled)) {
            POS.clear();
            camPrev = camCur = null;
            return;
        }
        Vec3d eye = new Vec3d(p.getX(), p.getEyeY(), p.getZ());
        camPrev = camCur != null ? camCur : eye;
        camCur = eye;
        fovMul += ((p.isSprinting() ? 1.15f : 1f) - fovMul) * 0.5f; // FOV ขยายตอนวิ่ง

        Set<Integer> seen = new HashSet<>();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity) || e == p) continue;
            int id = e.getId();
            seen.add(id);
            Vec3d now = new Vec3d(e.getX(), e.getY(), e.getZ());
            Vec3d[] old = POS.get(id);
            POS.put(id, new Vec3d[]{old != null ? old[1] : now, now});
        }
        POS.keySet().retainAll(seen);
        tickAt = System.nanoTime();
    }

    // ===== ฉายจุด 3D -> จอ =====
    private static boolean project(double x, double y, double z, double[] out) {
        double dx = x - camX, dy = y - camY, dz = z - camZ;
        double zc = dx * fx + dy * fy + dz * fz;
        if (zc < 0.1) return false; // อยู่หลังกล้อง
        double xc = dx * rx + dz * rz;
        double yc = dx * ux + dy * uy + dz * uz;
        out[0] = sw / 2.0 + xc / (zc * tanHalf * aspect) * sw / 2.0;
        out[1] = sh / 2.0 - yc / (zc * tanHalf) * sh / 2.0;
        return true;
    }

    private static void render(DrawContext ctx, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        boolean mob = ModuleManager.MOB_ESP.enabled, pl = ModuleManager.PLAYER_ESP.enabled;
        ClientPlayerEntity p = mc.player;
        if (!(mob || pl) || p == null || mc.world == null || camCur == null
                || mc.currentScreen != null || mc.options.hudHidden
                || !mc.options.getPerspective().isFirstPerson()) return;

        float a = MathHelper.clamp((System.nanoTime() - tickAt) / 50_000_000f, 0f, 1f);
        Vec3d cam = camPrev.lerp(camCur, a);
        camX = cam.x; camY = cam.y; camZ = cam.z;

        double yaw = Math.toRadians(p.getYaw()), pitch = Math.toRadians(p.getPitch());
        double cp = Math.cos(pitch);
        fx = -Math.sin(yaw) * cp; fy = -Math.sin(pitch); fz = Math.cos(yaw) * cp;
        rx = -Math.cos(yaw); rz = -Math.sin(yaw);
        ux = -rz * fy; uy = rz * fx - rx * fz; uz = rx * fy;
        sw = mc.getWindow().getScaledWidth();
        sh = mc.getWindow().getScaledHeight();
        aspect = sw / (double) sh;
        tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) * fovMul / 2.0);

        TextRenderer tr = mc.textRenderer;
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == p || !le.isAlive()) continue;

            if (e instanceof PlayerEntity) {
                if (!pl || le.isSpectator()) continue;
                draw(ctx, tr, le, a, cam, true, ModuleManager.PESP_RANGE.value, ModuleManager.PESP_SHOW.on,
                        ModuleManager.PESP_COLOR, ModuleManager.PESP_HP_TOP, ModuleManager.PESP_HP_LOW);
            } else if (mob) {
                int idx = mobIndex(e);
                if (idx < 0) continue;
                draw(ctx, tr, le, a, cam, false, ModuleManager.MESP_RANGE.value, ModuleManager.MESP_SHOW.on,
                        ModuleManager.MESP_COLORS[idx], ModuleManager.MESP_HP_TOP, ModuleManager.MESP_HP_LOW);
            }
        }
    }

    private static int mobIndex(Entity e) {
        String path = Registries.ENTITY_TYPE.getId(e.getType()).getPath();
        boolean[] on = ModuleManager.MESP_MOBS.on;
        for (int i = 0; i < on.length; i++) {
            if (!on[i]) continue;
            for (String id : ModuleManager.MOB_IDS[i]) {
                if (id.equals(path)) return i;
            }
        }
        return -1;
    }

    private static void draw(DrawContext ctx, TextRenderer tr, LivingEntity e, float a, Vec3d cam, boolean player,
                             double range, boolean[] show, Setting.Color color, Setting.Color hpTop, Setting.Color hpLow) {
        Vec3d[] pp = POS.get(e.getId());
        Vec3d pos = pp != null ? pp[0].lerp(pp[1], a) : new Vec3d(e.getX(), e.getY(), e.getZ());
        double dist = cam.distanceTo(pos);
        if (dist > range) return;

        double w = e.getWidth() / 2.0, h = e.getHeight();
        double[] pt = new double[2];
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            double cx = pos.x + ((i & 1) == 0 ? -w : w);
            double cy = pos.y + ((i & 2) == 0 ? 0 : h);
            double cz = pos.z + ((i & 4) == 0 ? -w : w);
            if (!project(cx, cy, cz, pt)) return;
            minX = Math.min(minX, pt[0]); maxX = Math.max(maxX, pt[0]);
            minY = Math.min(minY, pt[1]); maxY = Math.max(maxY, pt[1]);
        }
        int x1 = (int) Math.round(minX), x2 = Math.max(x1 + 3, (int) Math.round(maxX));
        int y1 = (int) Math.round(minY), y2 = Math.max(y1 + 3, (int) Math.round(maxY));
        if (x2 < -50 || x1 > sw + 50 || y2 < -50 || y1 > sh + 50) return; // อยู่นอกจอ

        int col = color.argb(e.getId() * 0.07);
        boolean visible = (col >>> 24) > 2; // ความโปร่งใส 0 = ล่องหน

        if (visible && show[0]) {
            int shade = (((col >>> 24) * 180) / 255) << 24;
            rect(ctx, x1 - 1, y1 - 1, x2 + 1, y2 + 1, shade);
            rect(ctx, x1 + 1, y1 + 1, x2 - 1, y2 - 1, shade);
            rect(ctx, x1, y1, x2, y2, col);
        }
        if (visible && show[1]) {
            line(ctx, sw / 2, sh, (x1 + x2) / 2, y2, col);
        }
        if (show[2]) {
            float ratio = MathHelper.clamp(e.getHealth() / Math.max(1f, e.getMaxHealth()), 0f, 1f);
            double ph = e.getId() * 0.07;
            int top = hpTop.argb(ph), low = hpLow.argb(ph);
            int bx = x1 - 6, bh = y2 - y1;
            int fillTop = y2 - Math.max(1, Math.round(bh * ratio));
            ctx.fill(bx - 1, y1 - 1, bx + 4, y2 + 1, 0xAA000000);
            ctx.fillGradient(bx, fillTop, bx + 3, y2, lerp(low, top, ratio), low);
            String hp = String.valueOf(Math.round(e.getHealth()));
            ctx.drawText(tr, hp, bx - 2 - tr.getWidth(hp), Math.max(y1, fillTop - 4), 0xFFFFFFFF, true);
        }
        if (show[3] || show[4]) {
            String label = "";
            if (show[3]) label = player ? e.getName().getString() : e.getType().getName().getString();
            if (show[4]) label += (label.isEmpty() ? "" : " ") + "[" + (int) dist + "m]";
            ctx.drawText(tr, label, (x1 + x2) / 2 - tr.getWidth(label) / 2, y1 - 11, 0xFFFFFFFF, true);
        }
    }

    // ===== ตัวช่วยวาด =====
    private static void rect(DrawContext c, int x1, int y1, int x2, int y2, int col) {
        c.fill(x1, y1, x2, y1 + 1, col);
        c.fill(x1, y2 - 1, x2, y2, col);
        c.fill(x1, y1 + 1, x1 + 1, y2 - 1, col);
        c.fill(x2 - 1, y1 + 1, x2, y2 - 1, col);
    }

    private static int lerp(int a, int b, float t) {
        int r = 0;
        for (int sh = 0; sh < 32; sh += 8) {
            int ca = (a >>> sh) & 0xFF, cb = (b >>> sh) & 0xFF;
            r |= (Math.round(ca + (cb - ca) * t) & 0xFF) << sh;
        }
        return r;
    }

    /** เส้นตรง 1px วาดเป็นช่วงสั้นๆ (เร็ว) */
    private static void line(DrawContext c, int x0, int y0, int x1, int y1, int col) {
        int lim = sw * 3;
        x0 = MathHelper.clamp(x0, -lim, lim); x1 = MathHelper.clamp(x1, -lim, lim);
        y0 = MathHelper.clamp(y0, -lim, lim); y1 = MathHelper.clamp(y1, -lim, lim);
        if (Math.abs(x1 - x0) >= Math.abs(y1 - y0)) {
            if (x0 > x1) { int t = x0; x0 = x1; x1 = t; t = y0; y0 = y1; y1 = t; }
            int n = x1 - x0, run = x0, cur = y0;
            for (int x = x0; x <= x1; x++) {
                int y = n == 0 ? y0 : y0 + (int) Math.round((double) (y1 - y0) * (x - x0) / n);
                if (y != cur) { c.fill(run, cur, x, cur + 1, col); run = x; cur = y; }
            }
            c.fill(run, cur, x1 + 1, cur + 1, col);
        } else {
            if (y0 > y1) { int t = x0; x0 = x1; x1 = t; t = y0; y0 = y1; y1 = t; }
            int n = y1 - y0, run = y0, cur = x0;
            for (int y = y0; y <= y1; y++) {
                int x = n == 0 ? x0 : x0 + (int) Math.round((double) (x1 - x0) * (y - y0) / n);
                if (x != cur) { c.fill(cur, run, cur + 1, y, col); run = y; cur = x; }
            }
            c.fill(cur, run, cur + 1, y1 + 1, col);
        }
    }
}
