package com.example.anchorcharge;

/** ค่าตั้งของโมดูล (แสดงในหน้าต่างที่คลิกขวา) */
public abstract class Setting {
    public final String name;

    protected Setting(String name) {
        this.name = name;
    }

    /** ปุ่มสลับตัวเลือก */
    public static final class Mode extends Setting {
        public final String[] options;
        public int index;

        public Mode(String name, String[] options, int index) {
            super(name);
            this.options = options;
            this.index = index;
        }

        public String get() { return options[index]; }
        public void next() { index = (index + 1) % options.length; }
    }

    /** สไลเดอร์ช่วง จาก lo ถึง hi */
    public static final class Range extends Setting {
        public final double min, max, step;
        public double lo, hi;

        public Range(String name, double min, double max, double step, double lo, double hi) {
            super(name);
            this.min = min;
            this.max = max;
            this.step = step;
            this.lo = lo;
            this.hi = hi;
        }
    }
}
