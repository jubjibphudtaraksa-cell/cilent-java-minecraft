package com.example.anchorcharge;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.concurrent.ThreadLocalRandom;

/** ค่าตั้งของโมดูล (แสดงในหน้าต่างที่คลิกขวา) */
public abstract class Setting {
    public final String name;

    protected Setting(String name) {
        this.name = name;
    }

    /** ปุ่มสลับตัวเลือก */
    public static final class Mode extends Setting {
        public final String[] options;
        public int index;

        public Mode(String name, String[] options, int index) {
            super(name);
            this.options = options;
            this.index = index;
        }

        public String get() { return options[index]; }
        public void next() { index = (index + 1) % options.length; }
    }

    /** สไลเดอร์ช่วง จาก lo ถึง hi */
    public static final class Range extends Setting {
        public final double min, max, step;
        public double lo, hi;

        public Range(String name, double min, double max, double step, double lo, double hi) {
            super(name);
            this.min = min;
            this.max = max;
            this.step = step;
            this.lo = lo;
            this.hi = hi;
        }

        /** สุ่มเวลาในช่วง lo-hi (ms) แล้วแปลงเป็น tick */
        public int randomTicks() {
            double ms = lo >= hi ? lo : ThreadLocalRandom.current().nextDouble(lo, hi);
            return (int) Math.ceil(ms / 50.0);
        }
    }

    /** ตั้งปุ่ม: คีย์บอร์ด หรือปุ่มเมาส์ (code >= 1000 = ปุ่มเมาส์ code-1000) ; -1 = ไม่ตั้ง */
    public static final class Key extends Setting {
        public int code;

        public Key(String name, int code) {
            super(name);
            this.code = code;
        }

        public boolean isDown() {
            if (code < 0) return false;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.getWindow() == null) return false;
            long h = mc.getWindow().getHandle();
            if (code >= 1000) return GLFW.glfwGetMouseButton(h, code - 1000) == GLFW.GLFW_PRESS;
            return GLFW.glfwGetKey(h, code) == GLFW.GLFW_PRESS;
        }

        public String label() {
            if (code < 0) return Lang.t("None");
            if (code == 1000) return Lang.t("Left Click");
            if (code == 1001) return Lang.t("Right Click");
            if (code >= 1000) return "Mouse " + (code - 1000 + 1);
            if (code >= GLFW.GLFW_KEY_F1 && code <= GLFW.GLFW_KEY_F12) return "F" + (code - GLFW.GLFW_KEY_F1 + 1);
            String n = GLFW.glfwGetKeyName(code, 0);
            if (n != null) return n.toUpperCase();
            switch (code) {
                case GLFW.GLFW_KEY_SPACE: return "Space";
                case GLFW.GLFW_KEY_LEFT_SHIFT: return "L-Shift";
                case GLFW.GLFW_KEY_RIGHT_SHIFT: return "R-Shift";
                case GLFW.GLFW_KEY_LEFT_CONTROL: return "L-Ctrl";
                case GLFW.GLFW_KEY_RIGHT_CONTROL: return "R-Ctrl";
                case GLFW.GLFW_KEY_LEFT_ALT: return "L-Alt";
                case GLFW.GLFW_KEY_RIGHT_ALT: return "R-Alt";
                case GLFW.GLFW_KEY_TAB: return "Tab";
                case GLFW.GLFW_KEY_CAPS_LOCK: return "Caps";
                case GLFW.GLFW_KEY_ENTER: return "Enter";
                case GLFW.GLFW_KEY_UP: return "Up";
                case GLFW.GLFW_KEY_DOWN: return "Down";
                case GLFW.GLFW_KEY_LEFT: return "Left";
                case GLFW.GLFW_KEY_RIGHT: return "Right";
                default: return "Key " + code;
            }
        }
    }
}
