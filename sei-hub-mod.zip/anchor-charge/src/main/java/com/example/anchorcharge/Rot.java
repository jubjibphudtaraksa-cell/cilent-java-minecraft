package com.example.anchorcharge;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** ตัวช่วย silent rotation: ส่งมุมให้เซิร์ฟเวอร์ โดยไม่แตะมุมกล้องฝั่งเรา */
public final class Rot {
    private Rot() {}

    /** ส่งมุมมองปลอมให้เซิร์ฟเวอร์ (กล้องเราไม่เปลี่ยน) */
    public static void send(MinecraftClient mc, ClientPlayerEntity p, float yaw, float pitch) {
        if (mc.getNetworkHandler() == null) return;
        mc.getNetworkHandler().sendPacket(
                new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, p.isOnGround(), p.horizontalCollision));
    }

    /** ส่งมุมจริงของเรากลับไปให้เซิร์ฟเวอร์ */
    public static void syncReal(MinecraftClient mc, ClientPlayerEntity p) {
        send(mc, p, p.getYaw(), p.getPitch());
    }

    /**
     * รันการกระทำ (วาง/ใช้/นั่ง/ตี) โดยหันฝั่งเซิร์ฟเวอร์ไปทาง yaw/pitch ที่ระบุ
     * แล้วคืนมุมกล้องจริงทันทีในแท็กเดียวกัน -> กล้อง/เมาส์เรา ไม่ถูกแตะเลย
     */
    public static void silent(MinecraftClient mc, ClientPlayerEntity p, float yaw, float pitch, Runnable action) {
        float oldYaw = p.getYaw(), oldPitch = p.getPitch();
        p.setYaw(yaw);
        p.setPitch(pitch);
        send(mc, p, yaw, pitch);
        try {
            action.run();
        } finally {
            p.setYaw(oldYaw);
            p.setPitch(oldPitch);
            syncReal(mc, p);
        }
    }

    /** เหมือน silent() แต่หันไปหาจุดในโลก */
    public static void silentAt(MinecraftClient mc, ClientPlayerEntity p, Vec3d target, Runnable action) {
        Vec3d eye = p.getEyePos();
        silent(mc, p, yawTo(eye, target), pitchTo(eye, target), action);
    }

    public static float yawTo(Vec3d from, Vec3d to) {
        return MathHelper.wrapDegrees((float) (Math.toDegrees(Math.atan2(to.z - from.z, to.x - from.x)) - 90.0));
    }

    public static float pitchTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x, dz = to.z - from.z;
        return MathHelper.clamp((float) -Math.toDegrees(Math.atan2(to.y - from.y, Math.sqrt(dx * dx + dz * dz))), -90f, 90f);
    }
}
