package com.example.anchorcharge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.HashSet;
import java.util.Set;
import java.util.function.Predicate;

/**
 * Auto MLG: ตกจากที่สูง -> ก่อนถึงพื้น
 *  - Water MLG: วางน้ำจากถัง แล้วเก็บน้ำคืนตอนลงถึงพื้น
 *  - Slime Block MLG: วางสไลม์บล็อกใต้เท้า
 *  - Boat MLG: วางเรือแล้วนั่ง (ลงจากเรือให้ตอนถึงพื้น)
 * ลำดับความสำคัญ: น้ำ > สไลม์ > เรือ (เลือกเฉพาะอันที่เปิดไว้และมีของอยู่ใน hotbar/มือรอง)
 */
public final class AutoMlg {
    private enum Phase { IDLE, WATER, BOAT }

    private static final double MIN_FALL = 3.0;     // ตกเกินกี่บล็อกถึงจะทำงาน
    private static final double REACH_HEIGHT = 2.85; // สูงจากพื้นไม่เกินนี้ถึงวางได้ (ระยะเอื้อมจากตา)

    private static Phase phase = Phase.IDLE;
    private static double peakY = 0;
    private static boolean armed = true;
    private static int t = 0;
    private static int prevSlot = -1;
    private static Hand mlgHand = Hand.MAIN_HAND;
    private static int mlgSlot = -1;
    private static boolean sneaking = false;
    private static int seated = 0;                       // นั่งเรืออยู่กี่แท็ก
    private static final Set<Integer> oldBoats = new HashSet<>(); // เรือที่มีอยู่ก่อนวาง (ไม่นับ)

    private AutoMlg() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoMlg::tick);
    }

    private static void finish(MinecraftClient mc, ClientPlayerEntity p) {
        if (sneaking) {
            mc.options.sneakKey.setPressed(false);
            sneaking = false;
        }
        if (p != null) {
            if (prevSlot >= 0) p.getInventory().setSelectedSlot(prevSlot);
        }
        prevSlot = -1;
        mlgSlot = -1;
        seated = 0;
        oldBoats.clear();
        phase = Phase.IDLE;
    }

    private static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (!ModuleManager.AUTO_MLG.enabled || p == null || w == null || mc.interactionManager == null) {
            if (phase != Phase.IDLE) finish(mc, p);
            return;
        }

        if (phase == Phase.WATER) { waterPickup(mc, p); return; }
        if (phase == Phase.BOAT) { boatPhase(mc, w, p); return; }

        // ===== IDLE: ตรวจว่ากำลังตกอยู่ไหม =====
        boolean safe = p.isOnGround() || p.isTouchingWater() || p.hasVehicle()
                || p.getAbilities().flying || p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
        if (safe) {
            peakY = p.getY();
            armed = true;
            return;
        }
        peakY = Math.max(peakY, p.getY());
        if (!armed) return;
        if (peakY - p.getY() < MIN_FALL || p.getVelocity().y > -0.3) return;

        BlockPos[] ground = new BlockPos[1];
        double h = heightAboveGround(w, p, ground);
        if (h < 0 || h > REACH_HEIGHT) return;

        if (ModuleManager.MLG_WATER.value && tryWater(mc, p)) { armed = false; return; }
        // สไลม์ต้องวางตอนเท้ายังอยู่เหนือช่องที่จะวาง (ไม่งั้นชนตัวผู้เล่น)
        if (ModuleManager.MLG_SLIME.value && h >= 1.05 && trySlime(mc, p, ground[0])) { armed = false; return; }
        if (ModuleManager.MLG_BOAT.value && tryBoat(mc, p)) { armed = false; }
    }

    /**
     * Silent rotation: ตั้ง pitch เป็น 90 (มองลง) เฉพาะตอนส่งแพ็กเก็ตใช้ไอเท็ม
     * แล้วคืนค่าเดิมทันทีในแท็กเดียวกัน -> เซิร์ฟเวอร์เห็นว่าเราหันลง
     * แต่กล้อง/มุมมองฝั่งเราไม่ขยับเลย (เรนเดอร์เกิดหลังจบแท็ก)
     * ไม่แตะ prevPitch/prevYaw เพื่อไม่ให้ภาพกระตุก
     */
    private static void useItemSilent(MinecraftClient mc, ClientPlayerEntity p, Hand hand) {
        Rot.silent(mc, p, p.getYaw(), 90f, () -> mc.interactionManager.interactItem(p, hand));
        p.swingHand(hand);
    }

    /** ระยะจากเท้าถึงบล็อกแข็งที่อยู่ข้างล่าง ; -1 = ไม่เจอ หรือข้างล่างเป็นของเหลว (ลงน้ำอยู่แล้ว) */
    private static double heightAboveGround(ClientWorld w, ClientPlayerEntity p, BlockPos[] out) {
        BlockPos.Mutable pos = new BlockPos.Mutable();
        int x = MathHelper.floor(p.getX());
        int z = MathHelper.floor(p.getZ());
        int startY = MathHelper.floor(p.getY());
        for (int y = startY; y >= startY - 8; y--) {
            pos.set(x, y, z);
            BlockState st = w.getBlockState(pos);
            if (!st.getFluidState().isEmpty()) return -1;
            if (!st.getCollisionShape(w, pos).isEmpty()) {
                out[0] = pos.toImmutable();
                return p.getY() - (y + 1);
            }
        }
        return -1;
    }

    /** หาของใน มือรอง/hotbar ; ถ้าเจอใน hotbar จะสลับช่องให้ */
    private static Hand pick(ClientPlayerEntity p, Predicate<ItemStack> f) {
        if (f.test(p.getOffHandStack())) {
            mlgSlot = -1;
            return Hand.OFF_HAND;
        }
        for (int i = 0; i < 9; i++) {
            if (f.test(p.getInventory().getStack(i))) {
                prevSlot = p.getInventory().getSelectedSlot();
                p.getInventory().setSelectedSlot(i);
                mlgSlot = i;
                return Hand.MAIN_HAND;
            }
        }
        return null;
    }

    private static boolean isBoat(ItemStack s) {
        if (s.isEmpty()) return false;
        String path = Registries.ITEM.getId(s.getItem()).getPath();
        return path.endsWith("_boat") || path.endsWith("_raft");
    }

    // ===== น้ำ =====
    private static boolean tryWater(MinecraftClient mc, ClientPlayerEntity p) {
        Hand h = pick(p, s -> s.isOf(Items.WATER_BUCKET));
        if (h == null) return false;
        mlgHand = h;
        useItemSilent(mc, p, h); // หันลงพื้นฝั่งเซิร์ฟเวอร์ แต่กล้องเราไม่หัน
        phase = Phase.WATER;
        t = 0;
        return true;
    }

    private static void waterPickup(MinecraftClient mc, ClientPlayerEntity p) {
        t++;
        if (t > 60) { finish(mc, p); return; }
        if (t < 3 || !(p.isOnGround() || p.isTouchingWater())) return;

        ItemStack st = mlgHand == Hand.OFF_HAND ? p.getOffHandStack() : p.getInventory().getStack(mlgSlot);
        if (st.isOf(Items.WATER_BUCKET)) { finish(mc, p); return; } // เก็บน้ำกลับมาแล้ว (หรือวางไม่สำเร็จ)
        if (!st.isOf(Items.BUCKET)) { finish(mc, p); return; }

        if (mlgHand == Hand.MAIN_HAND) p.getInventory().setSelectedSlot(mlgSlot);
        useItemSilent(mc, p, mlgHand); // ถังเปล่า -> เก็บน้ำ
    }

    // ===== สไลม์ =====
    private static boolean trySlime(MinecraftClient mc, ClientPlayerEntity p, BlockPos ground) {
        Hand h = pick(p, s -> s.isOf(Items.SLIME_BLOCK));
        if (h == null) return false;
        BlockHitResult top = new BlockHitResult(Vec3d.ofCenter(ground).add(0, 0.5, 0), Direction.UP, ground, false);
        Rot.silentAt(mc, p, top.getPos(), () -> mc.interactionManager.interactBlock(p, h, top)); // หันฝั่งเซิร์ฟเวอร์ไปที่บล็อก
        p.swingHand(h);
        finish(mc, p); // คืนช่องเดิมทันที
        return true;
    }

    // ===== เรือ =====
    private static boolean tryBoat(MinecraftClient mc, ClientPlayerEntity p) {
        Hand h = pick(p, AutoMlg::isBoat);
        if (h == null) return false;
        mlgHand = h;
        oldBoats.clear();
        for (Entity e : mc.world.getOtherEntities(p, p.getBoundingBox().expand(8, 8, 8))) {
            if (isBoatEntity(e)) oldBoats.add(e.getId());
        }
        seated = 0;
        useItemSilent(mc, p, h);
        phase = Phase.BOAT;
        t = 0;
        return true;
    }

    private static boolean isBoatEntity(Entity e) {
        String path = Registries.ENTITY_TYPE.getId(e.getType()).getPath();
        return path.endsWith("boat") || path.endsWith("raft");
    }

    /** เรือที่เพิ่งโผล่ (ไม่ใช่เรือเก่า) และยังไม่มีคนนั่ง ที่ใกล้เราสุด */
    private static Entity nearestNewBoat(ClientWorld w, ClientPlayerEntity p) {
        Entity best = null;
        double bd = Double.MAX_VALUE;
        for (Entity e : w.getOtherEntities(p, p.getBoundingBox().expand(8, 8, 8))) {
            if (!isBoatEntity(e) || e.hasPassengers() || oldBoats.contains(e.getId())) continue;
            double d = e.squaredDistanceTo(p);
            if (d < bd) { bd = d; best = e; }
        }
        return best;
    }

    private static void boatPhase(MinecraftClient mc, ClientWorld w, ClientPlayerEntity p) {
        t++;
        if (t > 80) { finish(mc, p); return; }

        if (!p.hasVehicle()) {
            if (sneaking || seated > 0) { finish(mc, p); return; } // ลงจากเรือเรียบร้อย
            Entity boat = nearestNewBoat(w, p);
            if (boat != null) {
                // ยกเลิก Shift ก่อน ไม่งั้นเซิร์ฟเวอร์ไม่ยอมให้นั่ง (ย่อตัว = ไม่ใช่การกดใช้)
                if (p.isSneaking()) mc.options.sneakKey.setPressed(false);
                final Entity b = boat;
                Rot.silentAt(mc, p, b.getBoundingBox().getCenter(),
                        () -> mc.interactionManager.interactEntity(p, b, mlgHand)); // นั่งเรือ (ลองซ้ำทุกแท็ก)
            }
            return;
        }

        seated++;
        Entity v = p.getVehicle();
        // นั่งอยู่ให้ครบอย่างน้อย 6 แท็กก่อน (เรือเกิดบนพื้นอยู่แล้ว ถ้าเช็กทันทีจะลงเรือเองทันที)
        if (seated >= 6 && v != null && (v.isOnGround() || v.isTouchingWater())) {
            mc.options.sneakKey.setPressed(true); // กด Shift ลงจากเรือ
            sneaking = true;
        }
    }
}
