package com.example.anchorcharge;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class HubScreen extends Screen {
    // ===== สี =====
    private static final int ACCENT = 0xFFE8661A;
    private static final int TEXT = 0xFFFFFFFF;
    private static final int TEXT_DIM = 0xFFB89C88;
    private static final int CARD = 0xB0401E0C;
    private static final int CARD_HOVER = 0xB0572B12;
    private static final int BTN = 0xFF5B2A12;
    private static final int BTN_HOVER = 0xFF7A3A18;

    private static final int SIDE = 140;
    private static final int CARD_H = 32;
    private static final int GAP = 6;

    private static int selected = 0; // index รวม main + general
    private static String query = "";

    private int px, py, pw, ph;
    private int scroll = 0;
    private boolean searchFocused = false;
    private Module settingsOpen = null;
    private Setting.Range dragRange = null;
    private int dragHandle = 0;
    private Setting.Key listeningKey = null;

    public HubScreen() {
        super(Text.literal("SEI HUB"));
    }

    private static List<String> allTabs() {
        List<String> l = new ArrayList<>();
        for (String s : ModuleManager.MAIN_TABS) l.add(s);
        for (String s : ModuleManager.GENERAL_TABS) l.add(s);
        return l;
    }

    private boolean onSettingsTab() {
        return allTabs().get(selected).equals(ModuleManager.SETTINGS_TAB);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x99000000); // ไม่เบลอ แค่ทำให้มืด
    }

    private void layout() {
        pw = Math.min(width - 16, 540);
        ph = Math.min(height - 16, 320);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
    }

    private int step() {
        return Math.max(14, Math.min(20, (ph - 96) / 12));
    }

    private int itemY(int i) {
        return py + 58 + i * step() + (i >= ModuleManager.MAIN_TABS.length ? 16 : 0);
    }

    private int listLeft() { return px + SIDE + 16; }
    private int listRight() { return px + pw - 14; }
    private int listTop() { return py + 52; }
    private int listBottom() { return py + ph - 10; }

    private int searchW() { return Math.min(150, pw - SIDE - 150); }
    private int searchX() { return listRight() - searchW(); }

    private List<Module> visible() {
        if (onSettingsTab()) return new ArrayList<>();
        List<Module> src = ModuleManager.TABS.get(allTabs().get(selected));
        if (query.isEmpty()) return src;
        List<Module> out = new ArrayList<>();
        String q = query.toLowerCase();
        for (Module m : src) {
            if (m.name.toLowerCase().contains(q) || Lang.t(m.name).toLowerCase().contains(q)) out.add(m);
        }
        return out;
    }

    // ===== วาด =====
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        layout();
        renderBackground(ctx, mx, my, delta);
        drawPanel(ctx);

        // ชื่อ
        ctx.drawText(textRenderer, Text.literal("SEI HUB").formatted(Formatting.BOLD), px + 20, py + 16, TEXT, true);
        ctx.drawText(textRenderer, Text.literal("V1").formatted(Formatting.BOLD),
                px + 20 + textRenderer.getWidth("SEI HUB") + 6, py + 16, ACCENT, true);
        ctx.fill(px + 16, py + 32, px + SIDE, py + 33, 0xFFB8500F);

        // แท็บ
        List<String> tabs = allTabs();
        ctx.drawText(textRenderer, Lang.t("MODULES"), px + 18, py + 45, TEXT_DIM, false);
        ctx.drawText(textRenderer, Lang.t("GENERAL"), px + 18, itemY(ModuleManager.MAIN_TABS.length) - 14, TEXT_DIM, false);
        int st = step();
        for (int i = 0; i < tabs.size(); i++) {
            int y = itemY(i);
            boolean sel = i == selected;
            boolean hov = mx >= px + 10 && mx <= px + SIDE + 4 && my >= y && my < y + st - 1;
            if (sel) rr(ctx, px + 10, y, SIDE - 6, st - 2, 5, 0x33FFFFFF);
            else if (hov) rr(ctx, px + 10, y, SIDE - 6, st - 2, 5, 0x18FFFFFF);
            int ty = y + (st - 2 - 8) / 2;
            rr(ctx, px + 18, ty, 8, 8, 2, sel ? ACCENT : 0xFF8A6A55);
            ctx.drawText(textRenderer, Lang.t(tabs.get(i)), px + 34, ty, sel ? TEXT : 0xFFD9C3B3, false);
            if (!tabs.get(i).equals(ModuleManager.SETTINGS_TAB)) {
                String cnt = String.valueOf(ModuleManager.TABS.get(tabs.get(i)).size());
                ctx.drawText(textRenderer, cnt, px + SIDE - 8 - textRenderer.getWidth(cnt), ty, TEXT_DIM, false);
            }
        }

        // หัวเนื้อหา
        String tab = tabs.get(selected);
        int cx = listLeft();
        if (onSettingsTab()) {
            ctx.drawText(textRenderer, Text.literal(Lang.t(tab)).formatted(Formatting.BOLD), cx, py + 16, TEXT, true);
            drawSettingsPage(ctx, mx, my);
        } else {
            List<Module> src = ModuleManager.TABS.get(tab);
            int on = 0;
            for (Module m : src) if (m.enabled) on++;
            String title = Lang.thai ? "โมดูล" + Lang.t(tab) : tab + " Modules";
            ctx.drawText(textRenderer, Text.literal(title).formatted(Formatting.BOLD), cx, py + 16, TEXT, true);
            String sub = Lang.thai ? src.size() + " โมดูล   " + on + " เปิดอยู่" : src.size() + " modules   " + on + " enabled";
            ctx.drawText(textRenderer, sub, cx, py + 31, TEXT_DIM, false);
            drawSearch(ctx);
            drawModuleList(ctx, mx, my);
        }

        if (settingsOpen != null) drawPopup(ctx, mx, my);
    }

    private void drawSearch(DrawContext ctx) {
        int sw = searchW(), sx = searchX(), sy = py + 14, sh = 20;
        if (sw <= 60) return;
        rr(ctx, sx, sy, sw, sh, 6, searchFocused ? 0xB0653010 : 0xB0401E0C);
        String shown = query.isEmpty() && !searchFocused ? Lang.t("Search modules") : query;
        int col = query.isEmpty() ? TEXT_DIM : TEXT;
        while (textRenderer.getWidth(shown) > sw - 16 && shown.length() > 1) shown = shown.substring(1);
        ctx.drawText(textRenderer, shown, sx + 8, sy + 6, col, false);
        if (searchFocused && (System.currentTimeMillis() / 500) % 2 == 0) {
            int cxp = sx + 8 + textRenderer.getWidth(query.isEmpty() ? "" : shown);
            ctx.fill(cxp, sy + 4, cxp + 1, sy + 16, TEXT);
        }
    }

    private void drawModuleList(DrawContext ctx, int mx, int my) {
        List<Module> vis = visible();
        int top = listTop(), bottom = listBottom(), left = listLeft(), right = listRight();
        int total = vis.size() * (CARD_H + GAP);
        int maxScroll = Math.max(0, total - (bottom - top));
        scroll = Math.max(0, Math.min(scroll, maxScroll));

        ctx.enableScissor(left, top, right, bottom);
        for (int i = 0; i < vis.size(); i++) {
            int y = top + i * (CARD_H + GAP) - scroll;
            if (y + CARD_H < top || y > bottom) continue;
            Module m = vis.get(i);
            boolean hov = mx >= left && mx <= right && my >= Math.max(y, top) && my <= Math.min(y + CARD_H, bottom);
            rr(ctx, left, y, right - left, CARD_H, 6, hov ? CARD_HOVER : CARD);
            ctx.drawText(textRenderer, Lang.t(m.name), left + 12, y + 7, TEXT, false);
            String d = Lang.t(m.desc);
            int maxW = right - left - 84;
            while (textRenderer.getWidth(d) > maxW && d.length() > 3) d = d.substring(0, d.length() - 1);
            ctx.drawText(textRenderer, d, left + 12, y + 18, TEXT_DIM, false);
            drawToggle(ctx, right - 38, y + (CARD_H - 14) / 2, m.enabled);
            if (!m.settings.isEmpty()) {
                ctx.drawText(textRenderer, "...", right - 58, y + 12, TEXT_DIM, false);
            }
        }
        if (vis.isEmpty()) {
            String t = Lang.t("No modules");
            ctx.drawText(textRenderer, t, left + ((right - left) - textRenderer.getWidth(t)) / 2, top + 20, TEXT_DIM, false);
        }
        ctx.disableScissor();
    }

    // ===== หน้า Settings Hub (เปลี่ยนภาษา) =====
    private int[] langBtn(int idx) { // idx 0 = English, 1 = ไทย
        int right = listRight();
        int w = 64, h = 20;
        int x = right - 12 - w - (1 - idx) * (w + 6);
        int y = listTop() + (CARD_H - h) / 2;
        return new int[]{x, y, w, h};
    }

    private void drawSettingsPage(DrawContext ctx, int mx, int my) {
        int left = listLeft(), right = listRight(), top = listTop();
        rr(ctx, left, top, right - left, CARD_H, 6, CARD);
        ctx.drawText(textRenderer, Lang.t("Language"), left + 12, top + 7, TEXT, false);
        ctx.drawText(textRenderer, Lang.t("Choose the menu language"), left + 12, top + 18, TEXT_DIM, false);
        String[] names = {"English", "ไทย"};
        for (int i = 0; i < 2; i++) {
            int[] b = langBtn(i);
            boolean active = (i == 1) == Lang.thai;
            boolean hov = mx >= b[0] && mx <= b[0] + b[2] && my >= b[1] && my <= b[1] + b[3];
            rr(ctx, b[0], b[1], b[2], b[3], 5, active ? ACCENT : (hov ? BTN_HOVER : BTN));
            ctx.drawText(textRenderer, names[i], b[0] + (b[2] - textRenderer.getWidth(names[i])) / 2, b[1] + 6, TEXT, false);
        }
    }

    // ===== หน้าต่างตั้งค่า (คลิกขวาที่โมดูล) =====
    private static int rowH(Setting s) {
        return s instanceof Setting.Range ? 46 : 38;
    }

    private int[] popup() {
        int w = 250, h = 44;
        for (Setting s : settingsOpen.settings) h += rowH(s);
        return new int[]{px + (pw - w) / 2, py + (ph - h) / 2, w, h};
    }

    private void closePopup() {
        settingsOpen = null;
        listeningKey = null;
        dragRange = null;
    }

    private void drawPopup(DrawContext ctx, int mx, int my) {
        rr(ctx, px, py, pw, ph, 12, 0x99000000);
        int[] p = popup();
        rr(ctx, p[0], p[1], p[2], p[3], 8, 0xF0301508);
        ctx.fill(p[0] + 12, p[1] + 26, p[0] + p[2] - 12, p[1] + 27, 0xFFB8500F);
        String title = Lang.t(settingsOpen.name);
        while (textRenderer.getWidth(title) > p[2] - 50 && title.length() > 3) title = title.substring(0, title.length() - 1);
        ctx.drawText(textRenderer, Text.literal(title).formatted(Formatting.BOLD), p[0] + 14, p[1] + 10, TEXT, true);
        ctx.drawText(textRenderer, "x", p[0] + p[2] - 18, p[1] + 10, TEXT_DIM, false);

        int y = p[1] + 34;
        int tx = p[0] + 18, tw = p[2] - 36;
        for (Setting s : settingsOpen.settings) {
            ctx.drawText(textRenderer, Lang.t(s.name), p[0] + 14, y + 2, TEXT_DIM, false);
            int bx = p[0] + 14, bw = p[2] - 28;
            boolean hov = mx >= bx && mx <= bx + bw && my >= y + 14 && my <= y + 32;
            if (s instanceof Setting.Mode m) {
                rr(ctx, bx, y + 14, bw, 18, 5, hov ? BTN_HOVER : BTN);
                String t = Lang.t(m.get());
                ctx.drawText(textRenderer, t, bx + (bw - textRenderer.getWidth(t)) / 2, y + 19, TEXT, false);
            } else if (s instanceof Setting.Key k) {
                boolean listening = listeningKey == k;
                rr(ctx, bx, y + 14, bw, 18, 5, listening ? ACCENT : (hov ? BTN_HOVER : BTN));
                String t = listening ? Lang.t("Press a key...") : k.label();
                ctx.drawText(textRenderer, t, bx + (bw - textRenderer.getWidth(t)) / 2, y + 19, TEXT, false);
            } else if (s instanceof Setting.Toggle tg) {
                rr(ctx, bx, y + 14, bw, 18, 5, tg.value ? ACCENT : (hov ? BTN_HOVER : BTN));
                String t = Lang.t(tg.value ? "On" : "Off");
                ctx.drawText(textRenderer, t, bx + (bw - textRenderer.getWidth(t)) / 2, y + 19, TEXT, false);
            } else if (s instanceof Setting.Range r) {
                String v = (int) r.lo + " - " + (int) r.hi;
                ctx.drawText(textRenderer, v, p[0] + p[2] - 14 - textRenderer.getWidth(v), y + 2, TEXT, false);
                int ty = y + 30;
                int xl = tx + (int) ((r.lo - r.min) / (r.max - r.min) * tw);
                int xh = tx + (int) ((r.hi - r.min) / (r.max - r.min) * tw);
                rr(ctx, tx, ty, tw, 4, 2, 0xFF5B4A40);
                rr(ctx, xl, ty, Math.max(4, xh - xl), 4, 2, ACCENT);
                rr(ctx, xl - 4, ty - 3, 8, 10, 4, 0xFFFFFFFF);
                rr(ctx, xh - 4, ty - 3, 8, 10, 4, 0xFFFFFFFF);
            }
            y += rowH(s);
        }
    }

    private double valueAt(Setting.Range r, double mx, int[] p) {
        int tx = p[0] + 18, tw = p[2] - 36;
        double t = Math.max(0, Math.min(1, (mx - tx) / tw));
        double v = r.min + t * (r.max - r.min);
        return r.min + Math.round((v - r.min) / r.step) * r.step;
    }

    private void setHandle(Setting.Range r, int handle, double v) {
        if (handle == 0) r.lo = Math.min(v, r.hi);
        else r.hi = Math.max(v, r.lo);
    }

    private void popupClick(double mx, double my) {
        int[] p = popup();
        if (mx < p[0] || mx > p[0] + p[2] || my < p[1] || my > p[1] + p[3]
                || (mx >= p[0] + p[2] - 26 && my <= p[1] + 24)) {
            closePopup();
            return;
        }
        Setting.Key was = listeningKey;
        listeningKey = null;
        int y = p[1] + 34;
        for (Setting s : settingsOpen.settings) {
            boolean onBtn = my >= y + 14 && my <= y + 32 && mx >= p[0] + 14 && mx <= p[0] + p[2] - 14;
            if (s instanceof Setting.Mode m) {
                if (onBtn) m.next();
            } else if (s instanceof Setting.Key k) {
                if (onBtn && was != k) listeningKey = k;
            } else if (s instanceof Setting.Toggle tg) {
                if (onBtn) tg.value = !tg.value;
            } else if (s instanceof Setting.Range r) {
                if (my >= y + 22 && my <= y + 44) {
                    double v = valueAt(r, mx, p);
                    dragRange = r;
                    if (v <= r.lo) dragHandle = 0;
                    else if (v >= r.hi) dragHandle = 1;
                    else dragHandle = (v - r.lo <= r.hi - v) ? 0 : 1;
                    setHandle(r, dragHandle, v);
                }
            }
            y += rowH(s);
        }
    }

    private void drawToggle(DrawContext ctx, int x, int y, boolean on) {
        rr(ctx, x, y, 28, 14, 7, on ? ACCENT : 0xFF5B4A40);
        int kx = on ? x + 28 - 12 : x + 2;
        rr(ctx, kx, y + 2, 10, 10, 5, 0xFFFFFFFF);
    }

    private void drawPanel(DrawContext ctx) {
        int r = 12;
        for (int i = 0; i < pw; i += 2) {
            int d = Math.min(i, pw - 1 - i);
            int inset = 0;
            if (d < r) {
                double dx = r - d - 0.5;
                inset = (int) Math.ceil(r - Math.sqrt(Math.max(0, r * r - dx * dx)));
            }
            float t = (float) i / pw;
            int col = lerp(0xFF2A1309, 0xFFB5500F, t * t);
            ctx.fill(px + i, py + inset, px + Math.min(i + 2, pw), py + ph - inset, col);
        }
        ctx.fillGradient(px + r, py + 2, px + pw - r, py + ph - 2, 0x00000000, 0x30FF9A40);
    }

    // ===== ตัวช่วยวาด =====
    private static int lerp(int a, int b, float t) {
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
        return 0xFF000000 | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    /** สี่เหลี่ยมมุมมน */
    private static void rr(DrawContext c, int x, int y, int w, int h, int r, int col) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) { c.fill(x, y, x + w, y + h, col); return; }
        c.fill(x + r, y, x + w - r, y + h, col);
        c.fill(x, y + r, x + r, y + h - r, col);
        c.fill(x + w - r, y + r, x + w, y + h - r, col);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.ceil(r - Math.sqrt(r * r - dy * dy));
            c.fill(x + inset, y + i, x + r, y + i + 1, col);
            c.fill(x + w - r, y + i, x + w - inset, y + i + 1, col);
            c.fill(x + inset, y + h - 1 - i, x + r, y + h - i, col);
            c.fill(x + w - r, y + h - 1 - i, x + w - inset, y + h - i, col);
        }
    }

    // ===== อินพุต =====
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int btn = click.button();

        if (settingsOpen != null) {
            if (listeningKey != null) { // ตั้งปุ่มด้วยเมาส์ (ซ้าย/ขวา/กลาง/ปุ่มข้าง)
                listeningKey.code = 1000 + btn;
                listeningKey = null;
            } else if (btn == 0) {
                popupClick(mx, my);
            }
            return true;
        }

        if (btn == 1) { // คลิกขวา = เปิดหน้าต่างตั้งค่า
            List<Module> v = visible();
            if (mx >= listLeft() && mx <= listRight() && my >= listTop() && my <= listBottom()) {
                for (int i = 0; i < v.size(); i++) {
                    int y = listTop() + i * (CARD_H + GAP) - scroll;
                    if (my >= y && my <= y + CARD_H && !v.get(i).settings.isEmpty()) {
                        settingsOpen = v.get(i);
                        searchFocused = false;
                        break;
                    }
                }
            }
            return true;
        }
        if (btn != 0) return super.mouseClicked(click, doubled);

        // แท็บ
        List<String> tabs = allTabs();
        int st = step();
        for (int i = 0; i < tabs.size(); i++) {
            int y = itemY(i);
            if (mx >= px + 10 && mx <= px + SIDE + 4 && my >= y && my < y + st - 1) {
                if (selected != i) { selected = i; scroll = 0; }
                searchFocused = false;
                return true;
            }
        }

        // หน้า Settings Hub: ปุ่มภาษา
        if (onSettingsTab()) {
            for (int i = 0; i < 2; i++) {
                int[] b = langBtn(i);
                if (mx >= b[0] && mx <= b[0] + b[2] && my >= b[1] && my <= b[1] + b[3]) {
                    Lang.thai = i == 1;
                    Lang.save();
                    return true;
                }
            }
            return super.mouseClicked(click, doubled);
        }

        // ช่องค้นหา
        int sw = searchW(), sx = searchX(), sy = py + 14;
        if (sw > 60 && mx >= sx && mx <= sx + sw && my >= sy && my <= sy + 20) {
            searchFocused = true;
            return true;
        }
        searchFocused = false;

        // การ์ดโมดูล
        List<Module> vis = visible();
        int top = listTop(), bottom = listBottom();
        if (mx >= listLeft() && mx <= listRight() && my >= top && my <= bottom) {
            for (int i = 0; i < vis.size(); i++) {
                int y = top + i * (CARD_H + GAP) - scroll;
                if (my >= y && my <= y + CARD_H) {
                    vis.get(i).toggle();
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragRange != null && settingsOpen != null) {
            setHandle(dragRange, dragHandle, valueAt(dragRange, click.x(), popup()));
            return true;
        }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragRange = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        if (settingsOpen != null) return true;
        scroll -= (int) (v * 18);
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (listeningKey != null) { // กำลังตั้งปุ่ม
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                // ยกเลิก
            } else if (key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE) {
                listeningKey.code = -1;
            } else {
                listeningKey.code = key;
            }
            listeningKey = null;
            return true;
        }
        if (settingsOpen != null && key == GLFW.GLFW_KEY_ESCAPE) {
            closePopup(); // ESC ครั้งแรกปิดหน้าต่างตั้งค่า
            return true;
        }
        if (searchFocused && key == GLFW.GLFW_KEY_BACKSPACE) {
            if (!query.isEmpty()) query = query.substring(0, query.length() - 1);
            scroll = 0;
            return true;
        }
        return super.keyPressed(input); // ESC = ปิด UI
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (searchFocused && input.codepoint() >= 32 && query.length() < 32) {
            query += new String(Character.toChars(input.codepoint()));
            scroll = 0;
            return true;
        }
        return super.charTyped(input);
    }
}
