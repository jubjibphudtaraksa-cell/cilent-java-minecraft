package com.example.anchorcharge;

import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/** ภาษาของเมนู: อังกฤษ / ไทย */
public final class Lang {
    public static boolean thai = false;
    private static final Map<String, String> TH = new HashMap<>();

    static {
        // แท็บ
        TH.put("Combat", "ต่อสู้");
        TH.put("Movement", "การเคลื่อนไหว");
        TH.put("Visuals", "ภาพ");
        TH.put("Macros", "มาโคร");
        TH.put("Utility", "ยูทิลิตี้");
        TH.put("Internals", "ระบบภายใน");
        TH.put("Detected", "ตรวจพบ");
        TH.put("Exploit", "เอ็กซ์พลอยต์");
        TH.put("Donut", "โดนัท");
        TH.put("Configs", "คอนฟิก");
        TH.put("Settings Hub", "ตั้งค่า Hub");
        TH.put("MODULES", "โมดูล");
        TH.put("GENERAL", "ทั่วไป");
        // ทั่วไป
        TH.put("Search modules", "ค้นหาโมดูล");
        TH.put("No modules", "ไม่มีโมดูล");
        TH.put("Language", "ภาษา");
        TH.put("Choose the menu language", "เลือกภาษาของเมนู");
        TH.put("Press a key...", "กดปุ่มที่ต้องการ...");
        TH.put("None", "ไม่มี");
        TH.put("Left Click", "คลิกซ้าย");
        TH.put("Right Click", "คลิกขวา");
        // โมดูล
        TH.put("Auto Respawn Anchor Charging", "ชาร์จ Respawn Anchor อัตโนมัติ");
        TH.put("Places glowstone into the anchor you place", "ใส่ Glowstone ให้ Anchor ที่คุณวางอัตโนมัติ");
        TH.put("Auto Crystal", "ออโต้คริสตัล");
        TH.put("Places and hits crystals while you hold a crystal and the key", "วางและตีคริสตัลอัตโนมัติ เมื่อถือคริสตัลและกดปุ่ม");
        TH.put("Auto Totem", "ออโต้โทเทม");
        TH.put("Moves a totem into your offhand when it is empty", "ย้ายโทเทมเข้ามือรองเมื่อมือรองว่าง");
        TH.put("Auto MLG", "ออโต้ MLG");
        TH.put("Places water, a slime block or a boat before you hit the ground", "วางน้ำ สไลม์บล็อก หรือเรือ ก่อนตกถึงพื้น");
        TH.put("Auto Mace", "ออโต้เมส");
        TH.put("Turns toward players in your FOV and hits them while you hold a Mace", "หันไปหาและตีผู้เล่นในเอฟโอวี เมื่อถือ Mace");
        TH.put("FOV", "เอฟโอวี");
        TH.put("CPS", "ความเร็วตี (CPS)");
        TH.put("Silent Aim", "ไซเลนต์เอม (กล้องไม่หัน)");
        TH.put("Show FOV Circle", "แสดงวงเอฟโอวี");
        TH.put("Circle Color", "สีวง");
        TH.put("Rainbow", "สายรุ้ง");
        TH.put("Red", "แดง");
        TH.put("Orange", "ส้ม");
        TH.put("Yellow", "เหลือง");
        TH.put("Green", "เขียว");
        TH.put("Cyan", "ฟ้า");
        TH.put("Blue", "น้ำเงิน");
        TH.put("Purple", "ม่วง");
        TH.put("Pink", "ชมพู");
        TH.put("White", "ขาว");
        TH.put("Kill Aura", "คิลออร่า");
        TH.put("Hits players in range (silent aim, adjustable CPS)", "ตีผู้เล่นในระยะ (ไซเลนต์เอม ปรับ CPS ได้)");
        TH.put("Mob Aura", "มอบออร่า");
        TH.put("Hits the mobs you pick in range (silent aim, adjustable CPS)", "ตีมอนที่เลือกในระยะ (ไซเลนต์เอม ปรับ CPS ได้)");
        TH.put("Range", "ระยะ");
        TH.put("Mobs", "มอนที่จะตี");
        TH.put("Zombie", "ซอมบี้");
        TH.put("Skeleton", "โครงกระดูก");
        TH.put("Creeper", "ครีปเปอร์");
        TH.put("Spider", "แมงมุม");
        TH.put("Enderman", "เอนเดอร์แมน");
        TH.put("Witch", "แม่มด");
        TH.put("Blaze", "เบลซ");
        TH.put("Slime", "สไลม์");
        TH.put("Piglin", "พิกลิน");
        TH.put("Drowned", "ดราวน์");
        TH.put("Pillager", "พิลเลเจอร์");
        TH.put("Phantom", "แฟนทอม");
        TH.put("Pig", "หมู");
        TH.put("Cow", "วัว");
        TH.put("Sheep", "แกะ");
        TH.put("Chicken", "ไก่");
        TH.put("Mob ESP", "ม็อบ ESP");
        TH.put("See mobs through walls: box, lines, health, name (color per mob)", "เห็นมอนทะลุกำแพง: กล่อง เส้น เลือด ชื่อ (ตั้งสีแต่ละมอนได้)");
        TH.put("Players ESP", "ผู้เล่น ESP");
        TH.put("See players through walls: box, lines, health bar, name", "เห็นผู้เล่นทะลุกำแพง: กล่อง เส้น แท่งเลือด ชื่อ");
        TH.put("Show", "แสดง");
        TH.put("Box", "กล่อง");
        TH.put("Lines", "เส้น");
        TH.put("Health", "เลือด");
        TH.put("Name", "ชื่อ");
        TH.put("Distance", "ระยะ");
        TH.put("Edit Color For", "ตั้งสีให้");
        TH.put("Mob Color", "สีของมอนนี้");
        TH.put("Health Bar Top", "สีแท่งเลือด (บน)");
        TH.put("Health Bar Bottom", "สีแท่งเลือด (ล่าง)");
        TH.put("Box / Line Color", "สีกล่อง / เส้น");
        TH.put("Opacity", "ความโปร่งใส");
        TH.put("Invisible", "ล่องหน");
        // ตั้งค่า
        TH.put("Water MLG", "MLG น้ำ");
        TH.put("Slime Block MLG", "MLG สไลม์บล็อก");
        TH.put("Boat MLG", "MLG เรือ");
        TH.put("On", "เปิด");
        TH.put("Off", "ปิด");
        TH.put("Mode", "โหมด");
        TH.put("Inventory Open", "เปิดกระเป๋า");
        TH.put("No Inventory", "ไม่เปิดกระเป๋า");
        TH.put("Delay (ms)", "หน่วงเวลา (ms)");
        TH.put("Charge Delay (ms)", "หน่วงตอนชาร์จ (ms)");
        TH.put("Place Delay (ms)", "หน่วงตอนวาง (ms)");
        TH.put("Hit Delay (ms)", "หน่วงตอนตี (ms)");
        TH.put("Key", "ปุ่ม");
    }

    private Lang() {}

    public static String t(String s) {
        return thai ? TH.getOrDefault(s, s) : s;
    }

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("sei-hub.properties");
    }

    public static void load() {
        try {
            Path f = file();
            if (Files.exists(f)) thai = Files.readString(f).trim().equals("lang=th");
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            Files.writeString(file(), thai ? "lang=th" : "lang=en");
        } catch (Exception ignored) {}
    }
}
