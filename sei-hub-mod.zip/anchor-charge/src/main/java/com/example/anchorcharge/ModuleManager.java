package com.example.anchorcharge;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ModuleManager {
    // ===== Combat =====
    public static final Module ANCHOR_CHARGE = new Module("Auto Respawn Anchor Charging",
            "Places glowstone into the anchor you place", true);
    public static final Setting.Range ANCHOR_DELAY = new Setting.Range("Charge Delay (ms)", 0, 1000, 10, 0, 100);

    public static final Module AUTO_CRYSTAL = new Module("Auto Crystal",
            "Places and hits crystals while you hold a crystal and the key", true);
    public static final Setting.Key CRYSTAL_KEY = new Setting.Key("Key", GLFW.GLFW_KEY_R);
    public static final Setting.Range CRYSTAL_PLACE = new Setting.Range("Place Delay (ms)", 0, 500, 10, 50, 100);
    public static final Setting.Range CRYSTAL_HIT = new Setting.Range("Hit Delay (ms)", 0, 500, 10, 50, 100);

    public static final Module AUTO_MACE = new Module("Auto Mace",
            "Turns toward players in your FOV and hits them while you hold a Mace", true);
    public static final Setting.Slider MACE_FOV = new Setting.Slider("FOV", 5, 60, 1, 25);
    public static final Setting.Range MACE_CPS = new Setting.Range("CPS", 1, 20, 1, 8, 12);
    public static final Setting.Toggle MACE_SILENT = new Setting.Toggle("Silent Aim", true);
    public static final Setting.Toggle MACE_CIRCLE = new Setting.Toggle("Show FOV Circle", true);
    public static final Setting.Mode MACE_COLOR = new Setting.Mode("Circle Color",
            new String[]{"Rainbow", "Red", "Orange", "Yellow", "Green", "Cyan", "Blue", "Purple", "Pink", "White"}, 0);

    // ===== Utility =====
    public static final Module AUTO_TOTEM = new Module("Auto Totem",
            "Moves a totem into your offhand when it is empty", true);
    public static final Setting.Mode TOTEM_MODE = new Setting.Mode("Mode",
            new String[]{"Inventory Open", "No Inventory"}, 0);
    public static final Setting.Range TOTEM_DELAY = new Setting.Range("Delay (ms)", 0, 1000, 10, 100, 250);

    public static final Module AUTO_MLG = new Module("Auto MLG",
            "Places water, a slime block or a boat before you hit the ground", true);
    public static final Setting.Toggle MLG_WATER = new Setting.Toggle("Water MLG", true);
    public static final Setting.Toggle MLG_SLIME = new Setting.Toggle("Slime Block MLG", true);
    public static final Setting.Toggle MLG_BOAT = new Setting.Toggle("Boat MLG", true);

    /** หมวดฝั่งซ้าย (MODULES) */
    public static final String[] MAIN_TABS = {
            "Combat", "Movement", "Visuals", "Macros", "Utility", "Internals", "Detected", "Exploit", "Donut"};
    /** หมวด GENERAL */
    public static final String[] GENERAL_TABS = {"Configs", "HUD", "Settings Hub"};
    public static final String SETTINGS_TAB = "Settings Hub";

    public static final Map<String, List<Module>> TABS = new LinkedHashMap<>();

    static {
        for (String t : MAIN_TABS) TABS.put(t, new ArrayList<>());
        for (String t : GENERAL_TABS) TABS.put(t, new ArrayList<>());

        ANCHOR_CHARGE.settings.add(ANCHOR_DELAY);
        AUTO_CRYSTAL.settings.add(CRYSTAL_KEY);
        AUTO_CRYSTAL.settings.add(CRYSTAL_PLACE);
        AUTO_CRYSTAL.settings.add(CRYSTAL_HIT);
        AUTO_TOTEM.settings.add(TOTEM_MODE);
        AUTO_TOTEM.settings.add(TOTEM_DELAY);

        TABS.get("Combat").add(ANCHOR_CHARGE);
        TABS.get("Combat").add(AUTO_CRYSTAL);
        AUTO_MACE.settings.add(MACE_FOV);
        AUTO_MACE.settings.add(MACE_CPS);
        AUTO_MACE.settings.add(MACE_SILENT);
        AUTO_MACE.settings.add(MACE_CIRCLE);
        AUTO_MACE.settings.add(MACE_COLOR);
        TABS.get("Combat").add(AUTO_MACE);
        AUTO_MLG.settings.add(MLG_WATER);
        AUTO_MLG.settings.add(MLG_SLIME);
        AUTO_MLG.settings.add(MLG_BOAT);

        TABS.get("Utility").add(AUTO_MLG);
        TABS.get("Utility").add(AUTO_TOTEM);
    }

    private ModuleManager() {}
}
