package com.example.anchorcharge;

import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ModuleManager {
    // ===== Combat =====
    public static final Module ANCHOR_CHARGE = new Module("Auto Respawn Anchor Charging",
            "Places glowstone into the anchor you place", true);
    public static final Setting.Range ANCHOR_DELAY = new Setting.Range("Charge Delay (ms)", 0, 1000, 10, 0, 100);

    public static final Module AUTO_CRYSTAL = new Module("Auto Crystal",
            "Places and hits crystals while you hold a crystal and the key", true);
    public static final Setting.Key CRYSTAL_KEY = new Setting.Key("Key", GLFW.GLFW_KEY_R);
    public static final Setting.Range CRYSTAL_PLACE = new Setting.Range("Place Delay (ms)", 0, 500, 10, 50, 100);
    public static final Setting.Range CRYSTAL_HIT = new Setting.Range("Hit Delay (ms)", 0, 500, 10, 50, 100);

    // ===== Utility =====
    public static final Module AUTO_TOTEM = new Module("Auto Totem",
            "Moves a totem into your offhand when it is empty", true);
    public static final Setting.Mode TOTEM_MODE = new Setting.Mode("Mode",
            new String[]{"Inventory Open", "No Inventory"}, 0);
    public static final Setting.Range TOTEM_DELAY = new Setting.Range("Delay (ms)", 0, 1000, 10, 100, 250);

    /** หมวดฝั่งซ้าย (MODULES) */
    public static final String[] MAIN_TABS = {
            "Combat", "Movement", "Visuals", "Macros", "Utility", "Internals", "Detected", "Exploit", "Donut"};
    /** หมวด GENERAL */
    public static final String[] GENERAL_TABS = {"Configs", "HUD", "Settings Hub"};
    public static final String SETTINGS_TAB = "Settings Hub";

    public static final Map<String, List<Module>> TABS = new LinkedHashMap<>();

    static {
        for (String t : MAIN_TABS) TABS.put(t, new ArrayList<>());
        for (String t : GENERAL_TABS) TABS.put(t, new ArrayList<>());

        ANCHOR_CHARGE.settings.add(ANCHOR_DELAY);
        AUTO_CRYSTAL.settings.add(CRYSTAL_KEY);
        AUTO_CRYSTAL.settings.add(CRYSTAL_PLACE);
        AUTO_CRYSTAL.settings.add(CRYSTAL_HIT);
        AUTO_TOTEM.settings.add(TOTEM_MODE);
        AUTO_TOTEM.settings.add(TOTEM_DELAY);

        TABS.get("Combat").add(ANCHOR_CHARGE);
        TABS.get("Combat").add(AUTO_CRYSTAL);
        TABS.get("Utility").add(AUTO_TOTEM);
    }

    private ModuleManager() {}
}
