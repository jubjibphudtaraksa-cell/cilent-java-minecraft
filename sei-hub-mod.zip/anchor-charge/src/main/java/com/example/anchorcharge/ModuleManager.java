package com.example.anchorcharge;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ModuleManager {
    // ===== ฟังก์ชันจริง =====
    public static final Module ANCHOR_CHARGE = new Module("Auto Respawn Anchor Charging",
            "Places glowstone into the anchor you place", true);
    public static final Module FASHCY = new Module("FashCy",
            "Breaks the crystal you place after a random delay", true);

    public static final Module AUTO_TOTEM = new Module("Auto Totem",
            "Moves a totem into your offhand when it is empty", true);
    public static final Setting.Mode TOTEM_MODE = new Setting.Mode("Mode",
            new String[]{"Inventory Open", "No Inventory"}, 0);
    public static final Setting.Range TOTEM_DELAY = new Setting.Range("Delay (ms)", 0, 1000, 10, 100, 250);

    /** หมวดฝั่งซ้าย (MODULES) */
    public static final String[] MAIN_TABS = {
            "Combat", "Movement", "Visuals", "Macros", "Utility", "Internals", "Detected", "Exploit", "Donut"};
    /** หมวด GENERAL */
    public static final String[] GENERAL_TABS = {"Configs", "HUD"};

    public static final Map<String, List<Module>> TABS = new LinkedHashMap<>();

    static {
        for (String t : MAIN_TABS) TABS.put(t, new ArrayList<>());
        for (String t : GENERAL_TABS) TABS.put(t, new ArrayList<>());

        List<Module> combat = TABS.get("Combat");
        combat.add(ANCHOR_CHARGE);
        combat.add(FASHCY);
        AUTO_TOTEM.settings.add(TOTEM_MODE);
        AUTO_TOTEM.settings.add(TOTEM_DELAY);
        TABS.get("Utility").add(AUTO_TOTEM);

        // ปุ่มใน UI ตามรูป (ยังไม่มีฟังก์ชัน)
        combat.add(new Module("Aim Assist", "Automatically aims at targets", false));
        combat.add(new Module("Anti Knockback", "Cancels knockback applied to you", false));
        combat.add(new Module("Auto Anchor", "Places anchors at the optimal position near your target", false));
        combat.add(new Module("Auto Crystal", "Automatically places and detonates crystals", false));
        combat.add(new Module("Auto Mace", "Automatically attacks while holding a mace.", false));
        combat.add(new Module("AutoCart", "Places rails and TNT minecarts while aiming", false));
        combat.add(new Module("Backtrack", "Allows you to attack targets at previous positions", false));
        combat.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
    }

    private ModuleManager() {}
}
