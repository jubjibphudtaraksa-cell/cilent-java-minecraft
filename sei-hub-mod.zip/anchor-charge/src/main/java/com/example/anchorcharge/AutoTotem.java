package com.example.anchorcharge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.Window;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

/**
 * ถ้ามือรองว่าง -> ย้าย Totem จากกระเป๋าเข้ามือรอง
 * โหมดเปิดกระเป๋า: เมาส์จะเลื่อนไปที่ช่อง Totem ก่อน แล้วค่อยหน่วงเวลาตามช่วงที่ตั้งไว้และสลับให้
 */
public final class AutoTotem {
    private static int waiting = -1;  // -1 = ยังไม่เริ่มนับ
    private static int cooldown = 0;  // พักหลังคลิก ให้เซิร์ฟเวอร์ซิงค์

    private AutoTotem() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoTotem::tick);
    }

    private static void tick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (!ModuleManager.AUTO_TOTEM.enabled || player == null || mc.interactionManager == null) {
            waiting = -1;
            return;
        }
        if (cooldown > 0) { cooldown--; return; }

        boolean inventoryMode = ModuleManager.TOTEM_MODE.index == 0;
        boolean invOpen = mc.currentScreen instanceof InventoryScreen;
        if (inventoryMode ? !invOpen : mc.currentScreen != null) {
            waiting = -1;
            return;
        }

        if (player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            waiting = -1;
            return;
        }

        int slot = -1;
        for (int i = 0; i < 36; i++) {
            if (player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                slot = i < 9 ? 36 + i : i; // ช่อง hotbar ใน screen handler = 36-44
                break;
            }
        }
        if (slot < 0) {
            waiting = -1;
            return;
        }

        // เปิดกระเป๋า: เลื่อนเมาส์ไปที่ช่อง Totem ก่อน
        if (inventoryMode && !moveCursorTo(mc, player, slot)) return;

        if (waiting < 0) waiting = ModuleManager.TOTEM_DELAY.randomTicks();
        if (waiting > 0) {
            waiting--;
            return;
        }

        // SWAP กับปุ่ม 40 = สลับกับมือรอง
        mc.interactionManager.clickSlot(player.playerScreenHandler.syncId, slot, 40,
                SlotActionType.SWAP, player);
        waiting = -1;
        cooldown = 2;
    }

    /** เลื่อนเมาส์เข้าหาช่อง 1 ก้าวต่อ tick ; คืน true เมื่อถึงแล้ว */
    private static boolean moveCursorTo(MinecraftClient mc, ClientPlayerEntity player, int slotIndex) {
        Window w = mc.getWindow();
        Slot s = player.playerScreenHandler.slots.get(slotIndex);

        // ตำแหน่งหน้าจอกระเป๋า (176x166) อยู่กลางจอ (ถ้าเปิดสมุดสูตรอาหารอยู่ ตำแหน่งจะเลื่อน)
        double gx = (mc.currentScreen.width - 176) / 2.0 + s.x + 8;
        double gy = (mc.currentScreen.height - 166) / 2.0 + s.y + 8;

        double ratio = (double) w.getWidth() / w.getScaledWidth();
        double tx = gx * ratio, ty = gy * ratio;

        double[] bx = new double[1], by = new double[1];
        GLFW.glfwGetCursorPos(w.getHandle(), bx, by);
        double dx = tx - bx[0], dy = ty - by[0];
        double dist = Math.hypot(dx, dy);
        if (dist <= 3 * ratio) return true;

        double step = Math.min(dist, Math.max(dist * 0.3, 8 * ratio));
        GLFW.glfwSetCursorPos(w.getHandle(), bx[0] + dx / dist * step, by[0] + dy / dist * step);
        return false;
    }
}
