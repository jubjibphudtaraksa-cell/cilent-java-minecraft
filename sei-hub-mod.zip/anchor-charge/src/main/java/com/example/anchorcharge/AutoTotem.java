package com.example.anchorcharge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

import java.util.concurrent.ThreadLocalRandom;

/** ถ้ามือรองว่าง -> ย้าย Totem จากกระเป๋าเข้ามือรอง (หน่วงเวลาสุ่มตามช่วงที่ตั้งไว้) */
public final class AutoTotem {
    private static int waiting = -1;  // -1 = ยังไม่เริ่มนับ
    private static int cooldown = 0;  // พักหลังคลิก ให้เซิร์ฟเวอร์ซิงค์

    private AutoTotem() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoTotem::tick);
    }

    private static void tick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        if (!ModuleManager.AUTO_TOTEM.enabled || player == null || mc.interactionManager == null) {
            waiting = -1;
            return;
        }
        if (cooldown > 0) { cooldown--; return; }

        boolean inventoryMode = ModuleManager.TOTEM_MODE.index == 0;
        boolean invOpen = mc.currentScreen instanceof InventoryScreen;
        if (inventoryMode ? !invOpen : mc.currentScreen != null) {
            waiting = -1;
            return;
        }

        if (player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            waiting = -1;
            return;
        }

        int slot = -1;
        for (int i = 0; i < 36; i++) {
            if (player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
                slot = i < 9 ? 36 + i : i; // ช่อง hotbar ใน screen handler = 36-44
                break;
            }
        }
        if (slot < 0) {
            waiting = -1;
            return;
        }

        if (waiting < 0) {
            double lo = ModuleManager.TOTEM_DELAY.lo, hi = ModuleManager.TOTEM_DELAY.hi;
            double ms = lo >= hi ? lo : ThreadLocalRandom.current().nextDouble(lo, hi);
            waiting = (int) Math.ceil(ms / 50.0);
        }
        if (waiting > 0) {
            waiting--;
            return;
        }

        // SWAP กับปุ่ม 40 = สลับกับมือรอง
        mc.interactionManager.clickSlot(player.playerScreenHandler.syncId, slot, 40,
                SlotActionType.SWAP, player);
        waiting = -1;
        cooldown = 2;
    }
}
