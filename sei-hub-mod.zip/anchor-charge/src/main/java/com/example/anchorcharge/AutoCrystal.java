package com.example.anchorcharge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/**
 * ถือคริสตัลค้างปุ่มที่ตั้งไว้ แล้ววนต่อเนื่อง:
 *  เล็งบล็อก Obsidian/Bedrock -> วาง -> ตี -> วางซ้ำที่เดิมทันที (ไม่ต้องรอคริสตัลเก่าหายจากฝั่งเรา) -> ...
 */
public final class AutoCrystal {
    private static long age = 0;
    private static int placeWait = -1;
    private static int hitWait = -1;
    private static BlockPos pendingBase = null; // ฐานที่เพิ่งตีคริสตัลไป รอวางซ้ำ
    private static int lastHitId = -1;          // คริสตัลที่เพิ่งตี (ข้ามไม่ตีซ้ำ)
    private static BlockPos placedPos = null;   // ตำแหน่งที่เพิ่งวาง รอคริสตัลโผล่
    private static long placedAt = -100;

    private AutoCrystal() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoCrystal::tick);
    }

    private static void reset() {
        placeWait = -1;
        hitWait = -1;
        pendingBase = null;
    }

    private static boolean validBase(ClientWorld w, BlockPos p) {
        return w.getBlockState(p).isOf(Blocks.OBSIDIAN) || w.getBlockState(p).isOf(Blocks.BEDROCK);
    }

    private static void tick(MinecraftClient mc) {
        age++;
        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;
        if (!ModuleManager.AUTO_CRYSTAL.enabled || player == null || world == null
                || mc.interactionManager == null || mc.currentScreen != null
                || !ModuleManager.CRYSTAL_KEY.isDown()) {
            reset();
            return;
        }

        Hand hand;
        if (player.getMainHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.MAIN_HAND;
        else if (player.getOffHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.OFF_HAND;
        else { reset(); return; }

        // 1) เพิ่งตีคริสตัลไป -> วางซ้ำที่ฐานเดิม (เซิร์ฟเวอร์ลบคริสตัลเก่าแล้ว)
        if (pendingBase != null) {
            if (!validBase(world, pendingBase)) {
                pendingBase = null;
            } else {
                if (placeWait < 0) placeWait = ModuleManager.CRYSTAL_PLACE.randomTicks();
                if (placeWait > 0) { placeWait--; return; }
                BlockHitResult top = new BlockHitResult(
                        Vec3d.ofCenter(pendingBase).add(0, 0.5, 0), Direction.UP, pendingBase, false);
                mc.interactionManager.interactBlock(player, hand, top);
                player.swingHand(hand);
                placedPos = pendingBase.up();
                placedAt = age;
                pendingBase = null;
                placeWait = -1;
                return;
            }
        }

        HitResult hr = mc.crosshairTarget;

        // 2) เล็งโดนคริสตัล -> ตี
        if (hr instanceof EntityHitResult ehr && ehr.getEntity() instanceof EndCrystalEntity crystal
                && crystal.getId() != lastHitId) {
            placeWait = -1;
            if (hitWait < 0) hitWait = ModuleManager.CRYSTAL_HIT.randomTicks();
            if (hitWait > 0) { hitWait--; return; }
            mc.interactionManager.attackEntity(player, crystal);
            player.swingHand(Hand.MAIN_HAND);
            lastHitId = crystal.getId();
            hitWait = -1;
            BlockPos base = crystal.getBlockPos().down();
            if (validBase(world, base)) pendingBase = base;
            return;
        }
        hitWait = -1;

        // 3) เล็งบล็อกที่วางได้ -> วางคริสตัล
        if (hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
            BlockPos base = bhr.getBlockPos();
            BlockPos above = base.up();
            // เพิ่งวางไป รอให้คริสตัลโผล่ก่อน (กันวางซ้ำเพราะปิง)
            if (above.equals(placedPos) && age - placedAt < 8) return;
            boolean free = world.isAir(above) && world.getOtherEntities(null, new Box(above)).isEmpty();
            if (validBase(world, base) && free) {
                if (placeWait < 0) placeWait = ModuleManager.CRYSTAL_PLACE.randomTicks();
                if (placeWait > 0) { placeWait--; return; }
                mc.interactionManager.interactBlock(player, hand, bhr);
                player.swingHand(hand);
                placedPos = above;
                placedAt = age;
                placeWait = -1;
                return;
            }
        }
        placeWait = -1;
    }
}
