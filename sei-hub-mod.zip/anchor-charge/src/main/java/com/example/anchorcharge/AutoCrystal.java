package com.example.anchorcharge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

/**
 * ถือคริสตัลค้างปุ่มที่ตั้งไว้:
 *  - เล็งบล็อก Obsidian/Bedrock -> วางคริสตัล (หน่วงตามช่วง Place Delay)
 *  - เล็งโดนคริสตัล -> ตี (หน่วงตามช่วง Hit Delay)
 */
public final class AutoCrystal {
    private static int placeWait = -1;
    private static int hitWait = -1;
    private static int cooldown = 0;

    private AutoCrystal() {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(AutoCrystal::tick);
    }

    private static void reset() {
        placeWait = -1;
        hitWait = -1;
    }

    private static void tick(MinecraftClient mc) {
        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;
        if (!ModuleManager.AUTO_CRYSTAL.enabled || player == null || world == null
                || mc.interactionManager == null || mc.currentScreen != null
                || !ModuleManager.CRYSTAL_KEY.isDown()) {
            reset();
            return;
        }

        Hand hand;
        if (player.getMainHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.MAIN_HAND;
        else if (player.getOffHandStack().isOf(Items.END_CRYSTAL)) hand = Hand.OFF_HAND;
        else { reset(); return; }

        if (cooldown > 0) { cooldown--; return; }

        HitResult hr = mc.crosshairTarget;

        // เล็งโดนคริสตัล -> ตี
        if (hr instanceof EntityHitResult ehr && ehr.getEntity() instanceof EndCrystalEntity crystal) {
            placeWait = -1;
            if (hitWait < 0) hitWait = ModuleManager.CRYSTAL_HIT.randomTicks();
            if (hitWait > 0) { hitWait--; return; }
            mc.interactionManager.attackEntity(player, crystal);
            player.swingHand(Hand.MAIN_HAND);
            hitWait = -1;
            cooldown = 1;
            return;
        }
        hitWait = -1;

        // เล็งบล็อกที่วางได้ -> วางคริสตัล
        if (hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
            BlockPos base = bhr.getBlockPos();
            BlockPos above = base.up();
            boolean okBase = world.getBlockState(base).isOf(Blocks.OBSIDIAN)
                    || world.getBlockState(base).isOf(Blocks.BEDROCK);
            boolean free = world.isAir(above) && world.getOtherEntities(null, new Box(above)).isEmpty();
            if (okBase && free) {
                if (placeWait < 0) placeWait = ModuleManager.CRYSTAL_PLACE.randomTicks();
                if (placeWait > 0) { placeWait--; return; }
                mc.interactionManager.interactBlock(player, hand, bhr);
                player.swingHand(hand);
                placeWait = -1;
                cooldown = 2;
                return;
            }
        }
        placeWait = -1;
    }
}
